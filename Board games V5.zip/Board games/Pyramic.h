#include "BoardGame_Classes.h"
#ifndef BOARD_GAMES_PYRAMIC_H
#define BOARD_GAMES_PYRAMIC_H

#include <vector>
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

template<typename T>
class Pyramic_board : public Board<T> {
private:
    vector<pair<int, char>> board; // Flattened board
    static const int levels = 3;

public:
    Pyramic_board() {
        board.clear();
        for (int i = 0; i <= 8; ++i) {
            board.emplace_back(i,'-');
        }
    }

    void display_board() {
        const int cell_width = 6; // Width of each cell
        const int total_width = levels * cell_width + (levels - 1) * cell_width; // Full width of the last level
        int currentIndex = 0;

        for (int i = 0; i < levels; ++i) {
            int numCells = 1 + (i * 2); // Calculate number of cells in the level

            // Calculate padding for alignment
            int padding = (total_width - (numCells * cell_width)) / 2;
            if (i == 1)cout << string(padding + 1, ' ');
            else if (i == 0)cout << string(padding + 2, ' ');
            else cout << string(padding, ' '); // Add left padding

            // Print each cell with separators
            for (int j = 0; j < numCells; ++j) {
                auto [index, symbol] = board[currentIndex++];
                cout << setw(cell_width) << left
                     << (" [" + to_string(index) + "] " + (symbol == ' ' ? "-" : string(1, symbol)));
                if (j < numCells - 1) cout << "|"; // Vertical separator
            }

            cout << "\n";
            if (i == 0) {
                cout << "             --------" << endl;
            } else if (i == 1) {
                cout<<"      -------+------+-------"<<endl;
            }

            else cout << "------+------+------+------+-----" << endl << endl;
        }
    }

    bool is_win() {
        // Hardcoded winning conditions for levels
        if (board[0].second == board[1].second && board[1].second == board[4].second && board[0].second != '-') return true;
        if (board[0].second == board[2].second && board[2].second == board[6].second && board[0].second != '-') return true;
        if (board[0].second == board[3].second && board[3].second == board[8].second && board[0].second != '-') return true;
        if (board[1].second == board[2].second && board[2].second == board[3].second && board[2].second != '-') return true;
        if (board[5].second == board[6].second && board[6].second == board[7].second && board[5].second != '-') return true;
        if (board[6].second == board[7].second && board[7].second == board[8].second && board[6].second != '-') return true;
        if (board[4].second == board[5].second && board[5].second == board[6].second && board[5].second != '-') return true;
        return false;
    }

    bool is_draw() {
        for(auto i:board){
            if(i.second=='-')return false;
        }
        return true;
    }

    bool game_is_over() {
        return is_win() || is_draw();
    }

    void update_board(int x, T symbol) {
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }

    }
    bool update_board(int x,int y,T symbol){}
};

#endif //BOARD_GAMES_PYRAMIC_H
