//
// Created by Youssef Elkhatib on 11/24/2024.
//

#ifndef BOARD_GAMES_GAMING_H
#define BOARD_GAMES_GAMING_H
#include "BoardGame_Classes.h"
#include "Computer_Player.h"
template<class T>
class Gaming{
private:
    vector<int> indexes;
    Board<T>* board_pointer;
    Player<T>* gaming_players[2];
    bool validate_index(string x){
        for(auto i:x){
            if(!isdigit(i))return false;
        }
        return true;
    }
public:
    Gaming(Board<T>* b, Player<T>* playerPtr[2], vector<int>& v)
    {
        board_pointer=b;
        gaming_players[0]=playerPtr[0];
        gaming_players[1]=playerPtr[1];
        indexes=v;
    }

    void run_game() {
        bool flag = true;

        while (true) {
            // Check if the game is over
            if (this->board_pointer->is_win()) {
                cout << this->gaming_players[1]->getname() << " WINS" << endl;
                break;
            }
            if (this->board_pointer->is_draw()) {
                cout << "It is a DRAW" << endl;
                break;
            }

            // Display the board on the first iteration
            if (flag) {
                this->board_pointer->display_board();
                flag = false;
            }

            // Loop through both players
            for (int i = 0; i < 2; ++i) {
                cout << this->gaming_players[i]->getname() << "'s turn" << endl;

                int x = -1; // To store the chosen move

                // Check if the player is a computer
                if (auto* compPlayer = dynamic_cast<Computer_Player<T>*>(this->gaming_players[i])) {
                    // Computer chooses move
                    random_device rd;  // Seed for randomness
                    mt19937 gen(rd()); // Mersenne Twister random number generator
                    uniform_int_distribution<> dist(0, indexes.size() - 1);

                    // Generate a random index
                    int random_index = dist(gen);

                    // Retrieve the value at the random index
                    int y = indexes[random_index];
                    cout<<compPlayer->getname()<<" chooses "<<y<<endl;
                    // Update the board
                    this->board_pointer->update_board(y, y, compPlayer->getsymbol());
                    this->board_pointer->display_board();

                    // Remove the chosen index
                    if (!indexes.empty()) {
                        indexes.erase(indexes.begin() + random_index);
                    } else {
                        cout << "No valid moves left." << endl;
                    }
                } else {
                    // Human player input
                    string index;
                    cout << "Please enter index" << endl;
                    cin >> index;

                    // Validate the input
                    auto it = find(indexes.begin(), indexes.end(), stoi(index));
                    while (true) {
                        if (!validate_index(index) || it == indexes.end()) {
                            cout << "Please enter a valid index (not chosen before)" << endl;
                            cin >> index;
                            it = find(indexes.begin(), indexes.end(), stoi(index));
                        } else {
                            break;
                        }
                    }
                    x = stoi(index);
                    indexes.erase(it);
                }

                // Perform the move
                this->gaming_players[i]->getmove(x, x);

                // Check for win or draw
                if (this->board_pointer->is_win()) {
                    cout << this->gaming_players[i]->getname() << " WINS" << endl;
                    return;
                }
                if (this->board_pointer->is_draw()) {
                    cout << "It is a DRAW" << endl;
                    return;
                }
            }
        }
    }

};


#endif //BOARD_GAMES_GAMING_H
