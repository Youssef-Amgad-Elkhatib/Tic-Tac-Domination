//
// Created by Youssef Elkhatib on 11/24/2024.
//

#ifndef BOARD_GAMES_COMPUTER_PLAYER_H
#define BOARD_GAMES_COMPUTER_PLAYER_H
#include "BoardGame_Classes.h"
#include "Pyramic.h"
#include <random>
template <class T>
class Computer_Player: public Player<T> {
    Pyramic_board<char>* b;
    bool pyramic=false;
public:
    Computer_Player(string x, T sym, Pyramic_board<char>& c)
    : Player<T>(x, sym), b(&c) {
        this->setBoard(b);
        pyramic= true;
    }
    void getmove(int& x,int&y){

    }
    void getmove(vector<int>& v){
        random_device rd;  // Seed for randomness
        mt19937 gen(rd()); // Mersenne Twister random number generator
        uniform_int_distribution<> dist(0, v.size() - 1);

        // Generate a random index
        int random_index = dist(gen);

        // Retrieve the value at the random index
        int x = v[random_index];

        if(pyramic) {
            b->update_board(x, this->symbol);
            b->display_board();
            v.erase(v.begin()+random_index);
        }
    }
};


#endif //BOARD_GAMES_COMPUTER_PLAYER_H
