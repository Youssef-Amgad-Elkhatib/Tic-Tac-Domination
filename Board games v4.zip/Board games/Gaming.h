//
// Created by Youssef Elkhatib on 11/24/2024.
//

#ifndef BOARD_GAMES_GAMING_H
#define BOARD_GAMES_GAMING_H
#include "BoardGame_Classes.h"
template<class T>
class Gaming{
private:
    vector<int> indexes;
    Board<T>* board_pointer;
    Player<T>* gaming_players[2];
    bool validate_index(string x){
        for(auto i:x){
            if(!isdigit(i))return false;
        }
        return true;
    }
public:
    Gaming(Board<T>* b, Player<T>* playerPtr[2], vector<int>& v)
    {
        board_pointer=b;
        gaming_players[0]=playerPtr[0];
        gaming_players[1]=playerPtr[1];
        indexes=v;
    }

    void run_game() {
        bool flag = true;

        while (true) {
            // Check if the game is won by Player 2
            if (this->board_pointer->is_win()) {
                cout << this->gaming_players[1]->getname() << " WINS" << endl;
                break;
            }

            // Check if the game is a draw
            if (this->board_pointer->is_draw()) {
                cout << "It is a DRAW" << endl;
                break;
            }

            // Display the board on the first iteration
            if (flag) {
                this->board_pointer->display_board();
                flag = false;
            }

            // Player 1's turn
            cout << this->gaming_players[0]->getname() << "'s turn" << endl;
            cout << "Please enter index" << endl;
            string index;
            cin >> index;

            // Validate Player 1's input
            auto it = find(indexes.begin(), indexes.end(), stoi(index));
            while (true) {
                if (!validate_index(index) || it == indexes.end()) {
                    cout << "Please enter a valid index (not chosen before)" << endl;
                    cin >> index;
                    it = find(indexes.begin(), indexes.end(), stoi(index));
                } else {
                    break;
                }
            }
            int x = stoi(index);
            indexes.erase(it);
            this->gaming_players[0]->getmove(x,x);

            // Check if Player 1 wins
            if (this->board_pointer->is_win()) {
                cout << this->gaming_players[0]->getname() << " WINS" << endl;
                break;
            }

            // Check if the game is a draw
            if (this->board_pointer->is_draw()) {
                cout << "It is a DRAW" << endl;
                break;
            }

            // Player 2's turn
            cout << this->gaming_players[1]->getname() << "'s turn" << endl;
            cout << "Please enter index" << endl;
            cin >> index;

            // Validate Player 2's input
            it = find(indexes.begin(), indexes.end(), stoi(index));
            while (true) {
                if (!validate_index(index) || it == indexes.end()) {
                    cout << "Please enter a valid index (not chosen before)" << endl;
                    cin >> index;
                    it = find(indexes.begin(), indexes.end(), stoi(index));
                } else {
                    break;
                }
            }
            x = stoi(index);
            indexes.erase(it);
            this->gaming_players[1]->getmove(x,x);
        }
    }
};


#endif //BOARD_GAMES_GAMING_H
