//
// Created by Youssef Elkhatib on 11/23/2024.
//

#ifndef BOARD_GAMES_HUMAN_PLAYER_H
#define BOARD_GAMES_HUMAN_PLAYER_H
#include "BoardGame_Classes.h"
#include "Pyramic.h"
template<class T>
class Human_Player : public Player<T> {
    Pyramic_board<char>* b;
    bool pyramic=false;
public:
    Human_Player(string x, T sym, Pyramic_board<char>& c)
            : Player<T>(x, sym), b(&c) {
        this->setBoard(b);
        pyramic= true;
    }
    void getmove(int& x,int&y){
        if(pyramic) {
            b->update_board(x, this->symbol);
            b->display_board();
        }
    }

    ~Human_Player(){pyramic=false;}
};



#endif //BOARD_GAMES_HUMAN_PLAYER_H
