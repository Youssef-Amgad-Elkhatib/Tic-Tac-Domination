//
// Created by Youssef Elkhatib on 11/23/2024.
//

#ifndef BOARD_GAMES_HUMAN_PLAYER_H
#define BOARD_GAMES_HUMAN_PLAYER_H
#include "BoardGame_Classes.h"
#include "Games.h"
template<class T>
class Human_Player : public Player<T> {
public:
    Human_Player(string x, T sym, Board<char>* c)
            : Player<T>(x, sym) {
        this->setBoard(c);
    }
    void getmove(int& x,int&y){
        this->boardPtr->update_board(x,x, this->symbol);
        this->boardPtr->display_board();
    }


};

template <class T>
class Computer_Player: public Player<T> {
public:
    Computer_Player(string x, T sym, Board<char>* c)
            : Player<T>(x, sym) {
        this->setBoard(c);
    }
    void getmove(int& x,int&y){}

};
template <class T>
class AI:public Player<T>{
public:
    AI(string x, T sym, Board<char>* c)
            : Player<T>(x, sym) {
        this->setBoard(c);
    }

};

#endif //BOARD_GAMES_HUMAN_PLAYER_H
