#include "BoardGame_Classes.h"
#ifndef BOARD_GAMES_PYRAMIC_H
#define BOARD_GAMES_PYRAMIC_H
#include <bits/stdc++.h>
using namespace std;
template<typename T>
class Pyramic_board : public Board<T> {
protected:
    vector<pair<int, char>> board; // Flattened board
    static const int levels = 3;

public:
    Pyramic_board() {
        board.clear();
        for (int i = 0; i <= 8; ++i) {
            board.emplace_back(i,'-');
        }
    }

    void display_board() {
        const int cell_width = 6; // Width of each cell
        const int total_width = levels * cell_width + (levels - 1) * cell_width; // Full width of the last level
        int currentIndex = 0;

        for (int i = 0; i < levels; ++i) {
            int numCells = 1 + (i * 2); // Calculate number of cells in the level

            // Calculate padding for alignment
            int padding = (total_width - (numCells * cell_width)) / 2;
            if (i == 1)cout << string(padding + 1, ' ');
            else if (i == 0)cout << string(padding + 2, ' ');
            else cout << string(padding, ' '); // Add left padding

            // Print each cell with separators
            for (int j = 0; j < numCells; ++j) {
                auto [index, symbol] = board[currentIndex++];
                cout << setw(cell_width) << left
                     << (" [" + to_string(index) + "] " + (symbol == ' ' ? "-" : string(1, symbol)));
                if (j < numCells - 1) cout << "|"; // Vertical separator
            }

            cout << "\n";
            if (i == 0) {
                cout << "             --------" << endl;
            } else if (i == 1) {
                cout<<"      -------+------+-------"<<endl;
            }

            else cout << "------+------+------+------+-----" << endl << endl;
        }
    }

    bool is_win() {
        // Hardcoded winning conditions for levels
        if (board[0].second == board[1].second && board[1].second == board[4].second && board[0].second != '-') return true;
        if (board[0].second == board[2].second && board[2].second == board[6].second && board[0].second != '-') return true;
        if (board[0].second == board[3].second && board[3].second == board[8].second && board[0].second != '-') return true;
        if (board[1].second == board[2].second && board[2].second == board[3].second && board[2].second != '-') return true;
        if (board[5].second == board[6].second && board[6].second == board[7].second && board[5].second != '-') return true;
        if (board[6].second == board[7].second && board[7].second == board[8].second && board[6].second != '-') return true;
        if (board[4].second == board[5].second && board[5].second == board[6].second && board[5].second != '-') return true;
        return false;
    }

    bool is_draw() {
        for(auto i:board){
            if(i.second=='-')return false;
        }
        return true;
    }

    bool game_is_over() {
        return is_win() || is_draw();
    }

    bool update_board(int x,int y,T symbol){
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }
        return true;
    }
};

//       game2 FourInRow       //
template <typename T>
class FourInARow : public Board<T> {
    std::vector<std::vector<std::pair<int, char>>> board;  // 2D vector for the board
    static const int rows = 6;     // Number of rows
    static const int columns = 7;  // Number of columns

public:
    FourInARow() {
        // Initialize the board with empty cells
        this->board.resize(rows, std::vector<std::pair<int, char>>(columns));

        // Fill each cell with a pair {column_index, '-'}
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < columns; ++j) {
                this->board[i][j] = {j, '-'}; // Each index initialized to '-' with its column index
            }
        }
        this->n_moves = 0;
    }

    bool update_board(int x, int y, T symbol) override {
        if(x<0 || x>6)return true;
        // Find the first empty spot in the column and place the symbol
        for (int i = rows - 1; i >= 0; --i) {
            if (board[i][x].second == '-') {  // Check if the cell is empty
                board[i][x].second = symbol;  // Place the symbol
                this->n_moves++;
                return true;
            }
        }
        return false; // Column is full
    }

    void display_board() override {
        std::cout << "0 1 2 3 4 5 6" << std::endl;
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < columns; ++j) {
                std::cout << board[i][j].second << " ";
            }
            std::cout << std::endl;
        }
        std::cout << std::endl;
    }

    bool is_win() override {
        // Check rows, columns, and diagonals for 4-in-a-row
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < columns; ++j) {
                char current = board[i][j].second;
                if (current != '-') {
                    // Check horizontally
                    if (j + 3 < columns &&
                        current == board[i][j + 1].second &&
                        current == board[i][j + 2].second &&
                        current == board[i][j + 3].second) {
                        return true;
                    }
                    // Check vertically
                    if (i + 3 < rows &&
                        current == board[i + 1][j].second &&
                        current == board[i + 2][j].second &&
                        current == board[i + 3][j].second) {
                        return true;
                    }
                    // Check diagonally (bottom-left to top-right)
                    if (i + 3 < rows && j + 3 < columns &&
                        current == board[i + 1][j + 1].second &&
                        current == board[i + 2][j + 2].second &&
                        current == board[i + 3][j + 3].second) {
                        return true;
                    }
                    // Check diagonally (top-left to bottom-right)
                    if (i - 3 >= 0 && j + 3 < columns &&
                        current == board[i - 1][j + 1].second &&
                        current == board[i - 2][j + 2].second &&
                        current == board[i - 3][j + 3].second) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    bool is_draw() override {
        return this->n_moves == rows * columns && !is_win();
    }

    bool game_is_over() override {
        return is_win() || is_draw();
    }

    bool check(int x, int y) {
        // Check if the column is full
        return board[0][x].second != '-'; // Column is full if the top row is not empty
    }
};



template<typename T>
class FiveByFiveBoard : public Board<T> {
private:
    vector<pair<int, char>> board; // 1D vector to represent the 5x5 board
    static const int size = 5; // Size of the board (5x5)
    int player1ThreeInARow;
    int player2ThreeInARow;
    bool draw=false;

public:
    // Constructor to initialize the board with pairs of (0, '-')
    FiveByFiveBoard() {
        board.clear();
        for (int i = 0; i <= 24; ++i) {
            board.emplace_back(i,'-');
        }
        player1ThreeInARow = 0;
        player2ThreeInARow = 0;
    }

    // Method to display the board
    void display_board() {
        const int cell_width = 6;
        const int separator_width = 1;
        int currentIndex = 0;

        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                auto [index, symbol] = board[currentIndex++];
                string index_str =  to_string(index);
                if(index>9)cout << setw(cell_width) << left
                                << ("[" + index_str + "] " + (symbol == '-' ? "-" : string(1, symbol)));
                else{
                    cout << setw(cell_width) << left
                         << ("[" + index_str + "]  " + (symbol == '-' ? "-" : string(1, symbol)));
                }
                if (j < size - 1) {
                    cout << "|";
                }
            }

            cout << "\n";

            if (i < size - 1) {
                cout << "------+------+------+------+------"<<endl;
            }
        }
        cout << "\n";
    }

// Method to check if there is a winner
    bool is_win() {
        int notfilled=0;
        for (auto& cell : board) {
            if (cell.second == '-') {
                notfilled++;
            }
            if(notfilled>1)return false;
        }
        // Check horizontal rows for three consecutive symbols
        for (int row = 0; row < size; ++row) {
            for (int col = 0; col <= size - 3; ++col) {
                int index1 = row * size + col;
                int index2 = row * size + col + 1;
                int index3 = row * size + col + 2;
                if (board[index1].second != '-' &&
                    board[index1].second == board[index2].second &&
                    board[index1].second == board[index3].second) {
                    if (board[index1].second == 'X') player1ThreeInARow++;
                    else if (board[index1].second == 'O') player2ThreeInARow++;
                }
            }
        }

        // Check vertical columns for three consecutive symbols
        for (int col = 0; col < size; ++col) {
            for (int row = 0; row <= size - 3; ++row) {
                int index1 = row * size + col;
                int index2 = (row + 1) * size + col;
                int index3 = (row + 2) * size + col;
                if (board[index1].second != '-' &&
                    board[index1].second == board[index2].second &&
                    board[index1].second == board[index3].second) {
                    if (board[index1].second == 'X') player1ThreeInARow++;
                    else if (board[index1].second == 'O') player2ThreeInARow++;
                }
            }
        }

        // Check diagonal (top-left to bottom-right) for three consecutive symbols
        for (int row = 0; row <= size - 3; ++row) {
            for (int col = 0; col <= size - 3; ++col) {
                int index1 = row * size + col;
                int index2 = (row + 1) * size + (col + 1);
                int index3 = (row + 2) * size + (col + 2);
                if (board[index1].second != '-' &&
                    board[index1].second == board[index2].second &&
                    board[index1].second == board[index3].second) {
                    if (board[index1].second == 'X') player1ThreeInARow++;
                    else if (board[index1].second == 'O') player2ThreeInARow++;
                }
            }
        }

        // Check diagonal (top-right to bottom-left) for three consecutive symbols
        for (int row = 0; row <= size - 3; ++row) {
            for (int col = 2; col < size; ++col) {
                int index1 = row * size + col;
                int index2 = (row + 1) * size + (col - 1);
                int index3 = (row + 2) * size + (col - 2);
                if (board[index1].second != '-' &&
                    board[index1].second == board[index2].second &&
                    board[index1].second == board[index3].second) {
                    if (board[index1].second == 'X') player1ThreeInARow++;
                    else if (board[index1].second == 'O') player2ThreeInARow++;
                }
            }
        }

        // Determine winner based on the number of three-in-a-row sequences
        if (player1ThreeInARow > player2ThreeInARow) return true; // Player 1 wins
        if (player2ThreeInARow > player1ThreeInARow) return true; // Player 2 wins
        else {
            draw= true;
            return false; // No winner yet
        }
    }

    // Method to check if the game is a draw (board is full)
    bool is_draw() {
        if(draw)return true;
        else return false;
    }

    // Method to update the board with a symbol ('X' or 'O')
    bool update_board(int x, int y, T symbol) {
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }
        return true;
    }

    // Method to check if the game is over (either a win or a draw)
    bool game_is_over() {
        return is_win() || is_draw(); // Game is over if there's a winner or if it's a draw
    }
};

template <typename T>
class MisereTicTacToe : public Board<T> {
private:
    vector<pair<int, T>> board; // 1D vector to represent the 3x3 board
    static const int size = 3;   // Size of the board (3x3)
    bool draw = false;
    bool win=false;
public:
    // Constructor to initialize the board with pairs of (index, '-')
    MisereTicTacToe() {
        board.clear();
        for (int i = 0; i < size * size; ++i) {
            board.emplace_back(i, '-');
        }
    }

    // Method to display the board
    void display_board() {
        if(win)return;
        const int cell_width = 6;
        int currentIndex = 0;

        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                auto [index, symbol] = board[currentIndex++];
                string index_str = to_string(index);
                cout << setw(cell_width) << left
                     << ("[" + index_str + "] " + (symbol == '-' ? "-" : string(1, symbol)));

                if (j < size - 1) {
                    cout << "|";
                }
            }

            cout << "\n";

            if (i < size - 1) {
                cout << "------+-------+------" << endl;
            }
        }
        cout << "\n";
    }

    // Method to check if there is a losing condition (three in a row)
    bool is_win() {
        if(win)return true;
        // Check horizontal rows for three consecutive symbols
        for (int row = 0; row < size; ++row) {
            int index1 = row * size;
            int index2 = row * size + 1;
            int index3 = row * size + 2;
            if (board[index1].second != '-' &&
                board[index1].second == board[index2].second &&
                board[index1].second == board[index3].second) {
                win= true; // Player loses
            }
        }

        // Check vertical columns for three consecutive symbols
        for (int col = 0; col < size; ++col) {
            int index1 = col;
            int index2 = size + col;
            int index3 = 2 * size + col;
            if (board[index1].second != '-' &&
                board[index1].second == board[index2].second &&
                board[index1].second == board[index3].second) {
                win=true; // Player loses
            }
        }

        // Check diagonal (top-left to bottom-right) for three consecutive symbols
        if (board[0].second != '-' &&
            board[0].second == board[4].second &&
            board[0].second == board[8].second) {
            win=true; // Player loses
        }

        // Check diagonal (top-right to bottom-left) for three consecutive symbols
        if (board[2].second != '-' &&
            board[2].second == board[4].second &&
            board[2].second == board[6].second) {
            win=true; // Player loses
        }

        return false; // No losing condition met
    }

    // Method to check if the game is a draw (board is full)
    bool is_draw() {
        for (const auto &cell : board) {
            if (cell.second == '-') {
                return false; // Still empty cells, not a draw
            }
        }
        if(win)return false;
        return !is_win(); // It's a draw if no one has lost
    }

    // Method to update the board with a symbol ('X' or 'O')
    bool update_board(int x, int y, T symbol) {
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }
        return true;
    }

    // Method to check if the game is over (either a loss or a draw)
    bool game_is_over() {
        if(win)return false;
        return is_draw();
    }
    bool get_win(){
        return win;
    }
};



template<typename T>
class SUS : public Board<T> {
private:
    vector<pair<int, T>> board; // 1D vector to represent the 3x3 board
    static const int size = 3; // Size of the board (3x3)
    int player1SUSCount;
    int player2SUSCount;
    bool draw = false;
    int chosenindex;
    char chosensymbol;
public:
    // Constructor to initialize the board with pairs of (0, '-')
    SUS() {
        board.clear();
        for (int i = 0; i < size * size; ++i) {
            board.emplace_back(i, '-');
        }
        player1SUSCount = 0;
        player2SUSCount = 0;
    }

    // Method to display the board
    void display_board() {
        const int cell_width = 6;
        const int separator_width = 1;
        int currentIndex = 0;

        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                auto [index, symbol] = board[currentIndex++];
                string index_str = to_string(index);
                if (index > 9) {
                    cout << setw(cell_width) << left << ("[" + index_str + "] " + (symbol == '-' ? "-" : string(1, symbol)));
                } else {
                    cout << setw(cell_width) << left << ("[" + index_str + "]  " + (symbol == '-' ? "-" : string(1, symbol)));
                }
                if (j < size - 1) {
                    cout << "|";
                }
            }
            cout << "\n";
            if (i < size - 1) {
                cout << "------+------+------" << endl;
            }
        }
        cout << "\n";
    }

    // Method to check if there is a winner based on "S-U-S" sequences
    bool is_win() {
        for(auto i:board){
            if(i.second == '-'){
                return false;
            }
        }
        cout<<player1SUSCount<<" "<<player2SUSCount<<endl;
        // Determine the winner based on the counts
        if (player1SUSCount > player2SUSCount) return true; // Player 1 wins
        else if (player2SUSCount > player1SUSCount) return true; // Player 2 wins
        else{
            draw = true;
            return false;
        }
    }

    void update_count(){
        if(chosensymbol=='S'){
            if(chosenindex==0){
                if(board[1].second=='U' && board[2].second=='S')player1SUSCount++;
                if(board[3].second=='U' && board[6].second=='S')player1SUSCount++;
                if(board[4].second=='U' && board[8].second=='S')player1SUSCount++;
            }
            else if(chosenindex==1){
                if(board[4].second=='U' && board[7].second=='S')player1SUSCount++;
            }
            else if(chosenindex==2){
                if(board[1].second=='U' && board[0].second=='S')player1SUSCount++;
                if(board[4].second=='U' && board[6].second=='S')player1SUSCount++;
                if(board[5].second=='U' && board[8].second=='S')player1SUSCount++;
            }
            else if(chosenindex==3){
                if(board[4].second=='U' && board[5].second=='S')player1SUSCount++;
            }
            else if(chosenindex==5){
                if(board[4].second=='U' && board[3].second=='S')player1SUSCount++;
            }
            else if(chosenindex==6){
                if(board[3].second=='U' && board[0].second=='S')player1SUSCount++;
                if(board[4].second=='U' && board[2].second=='S')player1SUSCount++;
                if(board[7].second=='U' && board[8].second=='S')player1SUSCount++;
            }
            else if(chosenindex==7){
                if(board[4].second=='U' && board[1].second=='S')player1SUSCount++;
            }
            else if(chosenindex==8){
                if(board[5].second=='U' && board[2].second=='S')player1SUSCount++;
                if(board[4].second=='U' && board[0].second=='S')player1SUSCount++;
                if(board[7].second=='U' && board[6].second=='S')player1SUSCount++;
            }
        }
        else{
            if(chosenindex==1){
                if(board[0].second=='S' && board[2].second=='S')player2SUSCount++;
            }
            else if(chosenindex==3){
                if(board[0].second=='S' && board[6].second=='S')player2SUSCount++;
            }
            else if(chosenindex==5){
                if(board[2].second=='S' && board[8].second=='S')player2SUSCount++;
            }
            else if(chosenindex==7){
                if(board[6].second=='S' && board[8].second=='S')player2SUSCount++;
            }
            else if(chosenindex==4){
                if(board[0].second=='S' && board[8].second=='S')player2SUSCount++;
                if(board[2].second=='S' && board[6].second=='S')player2SUSCount++;
                if(board[1].second=='S' && board[7].second=='S')player2SUSCount++;
                if(board[3].second=='S' && board[5].second=='S')player2SUSCount++;
            }
        }
    }



    // Method to check if the game is a draw (board is full)
    bool is_draw() {
        if(draw)return true;
        else return false;
    }

    // Method to update the board with a symbol ('S' or 'U')
    bool update_board(int x, int y, T symbol) {
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
                chosenindex=x;
                chosensymbol=symbol;
                update_count();
            }
        }
        return true;
    }

    // Method to check if the game is over (either a win or a draw)
    bool game_is_over() {
        return is_win() || is_draw(); // Game is over if there's a winner or if it's a draw
    }
};

template<class T>
class Word_Board: public Board<T>{
    vector<pair<int, T>> board; // 1D vector to represent the 3x3 board
    static const int size = 3; // Size of the board (3x3)
    vector<string> words;
public:
    Word_Board(){
        board.clear();
        for (int i = 0; i < size * size; ++i) {
            board.emplace_back(i, '-');
        }
        fstream file("dic.txt",ios::in);
        string holder;
        while(file>>holder){
            words.push_back(holder);
        }
        file.close();
    }
    char get_value(int index){
        return toupper(board[index].second);
    }
    void display_board() {
        const int cell_width = 6;
        const int separator_width = 1;
        int currentIndex = 0;

        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                auto [index, symbol] = board[currentIndex++];
                string index_str = to_string(index);
                if (index > 9) {
                    cout << setw(cell_width) << left << ("[" + index_str + "] " + (symbol == '-' ? "-" : string(1, symbol)));
                } else {
                    cout << setw(cell_width) << left << ("[" + index_str + "]  " + (symbol == '-' ? "-" : string(1, symbol)));
                }
                if (j < size - 1) {
                    cout << "|";
                }
            }
            cout << "\n";
            if (i < size - 1) {
                cout << "------+------+------" << endl;
            }
        }
        cout << "\n";
    }

    bool is_win(){
        string holder="";
        holder += board[0].second;
        holder += board[1].second;
        holder += board[2].second;
        auto it1=find(words.begin(), words.end(), holder);
        reverse(holder.begin(), holder.end());
        auto it2=find(words.begin(), words.end(), holder);
        if(it1!=words.end() || it2!=words.end())return true;
        holder.clear();

        holder += board[3].second;
        holder += board[4].second;
        holder += board[5].second;
        it1=find(words.begin(), words.end(), holder);
        reverse(holder.begin(), holder.end());
        it2=find(words.begin(), words.end(), holder);
        if(it1!=words.end() || it2!=words.end())return true;
        holder.clear();

        holder += board[6].second;
        holder += board[7].second;
        holder += board[8].second;
        it1=find(words.begin(), words.end(), holder);
        reverse(holder.begin(), holder.end());
        it2=find(words.begin(), words.end(), holder);
        if(it1!=words.end() || it2!=words.end())return true;
        holder.clear();

        holder += board[0].second;
        holder += board[3].second;
        holder += board[6].second;
        it1=find(words.begin(), words.end(), holder);
        reverse(holder.begin(), holder.end());
        it2=find(words.begin(), words.end(), holder);
        if(it1!=words.end() || it2!=words.end())return true;
        holder.clear();

        holder += board[1].second;
        holder += board[4].second;
        holder += board[7].second;
        it1=find(words.begin(), words.end(), holder);
        reverse(holder.begin(), holder.end());
        it2=find(words.begin(), words.end(), holder);
        if(it1!=words.end() || it2!=words.end())return true;
        holder.clear();

        holder += board[2].second;
        holder += board[5].second;
        holder += board[8].second;
        it1=find(words.begin(), words.end(), holder);
        reverse(holder.begin(), holder.end());
        it2=find(words.begin(), words.end(), holder);
        if(it1!=words.end() || it2!=words.end())return true;
        holder.clear();

        holder += board[0].second;
        holder += board[4].second;
        holder += board[8].second;
        it1=find(words.begin(), words.end(), holder);
        reverse(holder.begin(), holder.end());
        it2=find(words.begin(), words.end(), holder);
        if(it1!=words.end() || it2!=words.end())return true;
        holder.clear();

        holder += board[2].second;
        holder += board[4].second;
        holder += board[6].second;
        it1=find(words.begin(), words.end(), holder);
        reverse(holder.begin(), holder.end());
        it2=find(words.begin(), words.end(), holder);
        if(it1!=words.end() || it2!=words.end())return true;
        holder.clear();
        return false;
    }

    bool is_draw() {
        for(auto i:board){
            if(i.second=='-')return false;
        }
        return true;
    }

    bool game_is_over() {
        return is_win() || is_draw();
    }

    bool update_board(int x,int y,T symbol){
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }
        return true;
    }
};




template <typename T>
class NumericalBoard : public Board<T> {
    vector<pair<int, char>> board; // 1D vector to represent the 3x3 board
    static const int size = 3;     // Size of the board (3x3)

public:
    NumericalBoard() {
        board.clear();
        for (int i = 0; i <=8; ++i) {
            board.emplace_back(i, '-');
        }
        this->rows = size;
        this->columns = size;
        this->n_moves = 0;
    }

    // Convert 2D index to 1D index
    int to_index(int x, int y) {
        return x * this->columns + y;
    }

    bool update_board(int x, int y, T symbol) override {
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }
        return true;
    }

    void display_board() override {
        for (int i = 0; i < this->rows; ++i) {
            for (int j = 0; j < this->columns; ++j) {
                int index = to_index(i, j);

                // Print the character at the position or "-" if empty
                cout << "[" << board[index].first << "] "
                     << (board[index].second == '-' ? "-" : string(1, board[index].second))
                     << " ";

                // Add column separator
                if (j < this->columns - 1) {
                    cout << "|";
                }
            }
            cout << endl;

            // Add row separator (except after the last row)
            if (i < this->rows - 1) {
                for (int k = 0; k < this->columns; ++k) {
                    cout << "------"; // Adjust separator length as needed
                    if (k < this->columns - 1) {
                        cout << "+";
                    }
                }
                cout << endl;
            }
        }
    }

    bool is_win() override {
        auto char_to_int = [](char c) -> int {
            return c == '-' ? -100 : c - '0'; // Convert char to int or 0 if the cell is empty
        };

        if((char_to_int(board[0].second) + char_to_int(board[1].second) + char_to_int(board[2].second))==15)return true;
        if((char_to_int(board[3].second) + char_to_int(board[4].second) + char_to_int(board[5].second))==15)return true;
        if((char_to_int(board[6].second) + char_to_int(board[7].second) + char_to_int(board[8].second))==15)return true;
        if((char_to_int(board[0].second) + char_to_int(board[3].second) + char_to_int(board[6].second))==15)return true;
        if((char_to_int(board[1].second) + char_to_int(board[4].second) + char_to_int(board[7].second))==15)return true;
        if((char_to_int(board[2].second) + char_to_int(board[5].second) + char_to_int(board[8].second))==15)return true;
        if((char_to_int(board[0].second) + char_to_int(board[4].second) + char_to_int(board[8].second)==15))return true;
        if((char_to_int(board[2].second) + char_to_int(board[4].second) + char_to_int(board[6].second)==15))return true;
        return false;

    }

    bool is_draw() override {
        for(auto i:board){
            if(i.second=='-')return false;
        }
        return true;
    }

    bool game_is_over() override {
        return is_win() || is_draw();
    }
};

template <typename T>
class TicTacToe {
private:
    vector<pair<int, T>> board; // 1D vector to represent the 3x3 board
    static const int size = 3;   // Size of the board (3x3)
    // Method to display the board
    void display_board() {
        const int cell_width = 6;
        int currentIndex = 0;

        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                auto [index, symbol] = board[currentIndex++];
                string index_str = to_string(index);
                cout << setw(cell_width) << left
                     << ("[" + index_str + "] " + (symbol == '-' ? "-" : string(1, symbol)));

                if (j < size - 1) {
                    cout << "|";
                }
            }

            cout << "\n";

            if (i < size - 1) {
                cout << "------+-------+------" << endl;
            }
        }
        cout << "\n";
    }

    // Method to check if there is a losing condition (three in a row)
    char is_win() {

        // Check horizontal rows for three consecutive symbols
        for (int row = 0; row < size; ++row) {
            int index1 = row * size;
            int index2 = row * size + 1;
            int index3 = row * size + 2;
            if (board[index1].second != '-' &&
                board[index1].second == board[index2].second &&
                board[index1].second == board[index3].second) {
                return board[index1].second;
            }
        }

        // Check vertical columns for three consecutive symbols
        for (int col = 0; col < size; ++col) {
            int index1 = col;
            int index2 = size + col;
            int index3 = 2 * size + col;
            if (board[index1].second != '-' &&
                board[index1].second == board[index2].second &&
                board[index1].second == board[index3].second) {
                return board[index1].second;
            }
        }

        // Check diagonal (top-left to bottom-right) for three consecutive symbols
        if (board[0].second != '-' &&
            board[0].second == board[4].second &&
            board[0].second == board[8].second) {
            return board[0].second;
        }

        // Check diagonal (top-right to bottom-left) for three consecutive symbols
        if (board[2].second != '-' &&
            board[2].second == board[4].second &&
            board[2].second == board[6].second) {
            return board[2].second;
        }

        return 'F'; // No losing condition met
    }

    // Method to check if the game is a draw (board is full)
    char is_draw() {
        for (const auto &cell : board) {
            if (cell.second == '-') {
                return 'F'; // Still empty cells, not a draw
            }
        }
        return 'D';
    }
    bool special=false;
public:
    // Constructor to initialize the board with pairs of (index, '-')
    TicTacToe() {
        board.clear();
        for (int i = 0; i < size * size; ++i) {
            board.emplace_back(i, '-');
        }
    }
    char play(T symbol,int n){
        while(true){
            this->display_board();
            string index;
            if(n==1) {
                cout << "Please choose an index" << endl;
                cin >> index;
                while (true) {
                    if (index.length() != 1 || !isdigit(index[0]) || board[stoi(index)].second != '-') {
                        cout << "Please enter a valid index not chosen before" << endl;
                        cin >> index;
                    }
                    else break;
                }
                cout<<"Index chosen: "<<index<<endl<<endl;
            }
            else if(n==2){
                start:
                random_device rd;
                mt19937 gen(rd());
                uniform_int_distribution<> dist(0, 8);
                index = to_string(dist(gen));
                if(board[stoi(index)].second!='-')goto start;
                cout<<"Index chosen: "<<index<<endl<<endl;
            }
            board[stoi(index)].second=symbol;
            if(is_win()!='F'){
                cout<<symbol<<" Wins this board"<<endl<<endl;
                return symbol;
            }
            else if(is_draw()!='F'){
                cout<<"IT is a Draw on this board"<<endl<<endl;
                return 'D';
            }
            if(special){
                if(n==1)n=2;
                else n=1;
            }
            if(symbol=='X')symbol='O';
            else symbol='X';
        }

    }

    void set_special(){
        special=true;
    }




};

template <typename T>
class UltimateTicTacToe : public Board<T> {
private:
    vector<pair<int, T>> board; // 1D vector to represent the 3x3 board
    static const int size = 3;   // Size of the board (3x3)
public:
    // Constructor to initialize the board with pairs of (index, '-')
    UltimateTicTacToe() {
        board.clear();
        for (int i = 0; i < size * size; ++i) {
            board.emplace_back(i, '-');
        }
    }

    // Method to display the board
    void display_board() {
        const int cell_width = 6;
        int currentIndex = 0;

        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                auto [index, symbol] = board[currentIndex++];
                string index_str = to_string(index);
                cout << setw(cell_width) << left
                     << ("[" + index_str + "] " + (symbol == '-' ? "-" : string(1, symbol)));

                if (j < size - 1) {
                    cout << "|";
                }
            }

            cout << "\n";

            if (i < size - 1) {
                cout << "------+-------+------" << endl;
            }
        }
        cout << "\n";
    }

    // Method to check if there is a losing condition (three in a row)
    bool is_win() {
        // Check horizontal rows for three consecutive symbols
        for (int row = 0; row < size; ++row) {
            int index1 = row * size;
            int index2 = row * size + 1;
            int index3 = row * size + 2;
            if (board[index1].second != '-' &&
                board[index1].second == board[index2].second &&
                board[index1].second == board[index3].second) {
                return true;
            }
        }

        // Check vertical columns for three consecutive symbols
        for (int col = 0; col < size; ++col) {
            int index1 = col;
            int index2 = size + col;
            int index3 = 2 * size + col;
            if (board[index1].second != '-' &&
                board[index1].second == board[index2].second &&
                board[index1].second == board[index3].second) {
                return true;
            }
        }

        // Check diagonal (top-left to bottom-right) for three consecutive symbols
        if (board[0].second != '-' &&
            board[0].second == board[4].second &&
            board[0].second == board[8].second) {
            return true;
        }

        // Check diagonal (top-right to bottom-left) for three consecutive symbols
        if (board[2].second != '-' &&
            board[2].second == board[4].second &&
            board[2].second == board[6].second) {
            return true;
        }

        return false; // No winning condition met
    }

    // Method to check if the game is a draw (board is full)
    bool is_draw() {
        for (const auto &cell : board) {
            if (cell.second == '-') {
                return false; // Still empty cells, not a draw
            }
        }
        return true;
    }

    // Method to update the board with a symbol ('X' or 'O')
    bool update_board(int x, int y, T symbol) {
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }
        return true;
    }

    // Method to check if the game is over (either a loss or a draw)
    bool game_is_over() {
        return is_win() || is_draw();
    }

};
#endif