#ifndef BOARD_GAMES_HUMAN_PLAYER_H
#define BOARD_GAMES_HUMAN_PLAYER_H
#include "BoardGame_Classes.h"
#include "Games.h"
template<class T>
class Human_Player : public Player<T> {
    bool validate_index(string x){
        for(auto i:x){
            if(!isdigit(i))return false;
        }
        return true;
    }
public:
    Human_Player(string x, T sym, Board<char>* c)
            : Player<T>(x, sym) {
        this->setBoard(c);
    }
    void getmove(int& x,int&y){
        this->boardPtr->update_board(x,x, this->symbol);
        this->boardPtr->display_board();
    }
    void setsymbol(char c){
        this->symbol=c;
    }

    void make_move(vector<int>& indexes, Board<T>* board_pointer) {
        int chosenIndex = -1;
        string index;

        // Prompt the human player for input
        cout << this->getname() << ", please enter an index:" << endl;
        cin >> index;

        // Input validation loop
        while (true) {
            // Check if the input is a valid number and within the allowed indexes
            if (!validate_index(index)) {
                cout << "Invalid input. Please enter a valid index:" << endl;
                cin >> index;
                continue;
            }

            chosenIndex = stoi(index);
            auto it = find(indexes.begin(), indexes.end(), chosenIndex);

            // Check if the chosen index is available
            if (it == indexes.end()) {
                cout << "Index already chosen or out of range. Please enter a valid index:" << endl;
                cin >> index;
            } else {
                // Valid move
                indexes.erase(it); // Remove the chosen index
                break;
            }
        }

        // Update the board with the player's move
        board_pointer->update_board(chosenIndex, chosenIndex, this->getsymbol());
        board_pointer->display_board();
    }

};

template <class T>
class Computer_Player: public Player<T> {
public:
    Computer_Player(string x, T sym, Board<char>* c)
            : Player<T>(x, sym) {
        this->setBoard(c);
    }
    void getmove(int& x,int&y){}
    void setsymbol(char c){
        this->symbol=c;
    }
    void make_move(vector<int>& indexes, Board<T>* board_pointer) {
        if (indexes.empty()) {
            cout << "No valid moves left." << endl;
            return;
        }

        // Random move selection
        random_device rd;  // Seed for randomness
        mt19937 gen(rd()); // Mersenne Twister random number generator
        uniform_int_distribution<> dist(0, indexes.size() - 1);

        // Generate a random index
        int random_index = dist(gen);

        // Retrieve the value at the random index
        int chosenIndex = indexes[random_index];
        cout << this->getname() << " chooses " << chosenIndex << endl;

        // Update the board with the computer's move
        board_pointer->update_board(chosenIndex, chosenIndex, this->getsymbol());
        board_pointer->display_board();

        // Remove the chosen index from the available indexes
        indexes.erase(indexes.begin() + random_index);
    }

};
template <class T>
class AI:public Player<T>{
    int minimax(Board<T>* board, bool isMaximizing, T aiSymbol, T opponentSymbol, int alpha, int beta, const vector<int>& indexes) {
        // Base case: Check terminal state
        if (board->is_win()) {
            return isMaximizing ? -1 : 1; // AI loses if opponent wins, and vice versa
        }
        if (board->is_draw() || indexes.empty()) {
            return 0; // Draw
        }

        // Recursive case
        if (isMaximizing) {
            int bestScore = INT_MIN;

            // Iterate through all possible moves
            for (int index : indexes) {
                // Simulate the move
                board->update_board(index, index, aiSymbol);

                // Create updated indexes for recursion
                vector<int> updatedIndexes = indexes;
                updatedIndexes.erase(find(updatedIndexes.begin(), updatedIndexes.end(), index));

                // Evaluate recursively
                int score = minimax(board, false, aiSymbol, opponentSymbol, alpha, beta, updatedIndexes);

                // Undo the move
                board->update_board(index, index, '-');

                bestScore = max(bestScore, score);
                alpha = max(alpha, bestScore);

                // Prune unnecessary branches
                if (beta <= alpha) {
                    break;
                }
            }
            return bestScore;
        } else {
            int bestScore = INT_MAX;

            // Iterate through all possible moves
            for (int index : indexes) {
                // Simulate the move
                board->update_board(index, index, opponentSymbol);

                // Create updated indexes for recursion
                vector<int> updatedIndexes = indexes;
                updatedIndexes.erase(find(updatedIndexes.begin(), updatedIndexes.end(), index));

                // Evaluate recursively
                int score = minimax(board, true, aiSymbol, opponentSymbol, alpha, beta, updatedIndexes);

                // Undo the move
                board->update_board(index, index, '-');

                bestScore = min(bestScore, score);
                beta = min(beta, bestScore);

                // Prune unnecessary branches
                if (beta <= alpha) {
                    break;
                }
            }
            return bestScore;
        }
    }
public:
    AI(string x, T sym, Board<char>* c)
            : Player<T>(x, sym) {
        this->setBoard(c);
    }
    void getmove(int&x, int&y){}
    void setsymbol(char c){
        this->symbol=c;
    }
    void make_move(vector<int>& indexes, Player<T>* gaming_players[2], Board<T>* board_pointer) {
        int bestMove = -1;

        // Determine the AI's index and the opponent's index dynamically
        int aiIndex = (gaming_players[0] == this) ? 0 : 1;
        int opponentIndex = 1 - aiIndex; // The other player is the opponent

        T aiSymbol = this->getsymbol();
        T opponentSymbol = gaming_players[opponentIndex]->getsymbol();

        // Step 1: Try to win in the current turn
        for (int index : indexes) {
            board_pointer->update_board(index, index, aiSymbol);
            if (board_pointer->is_win()) {
                bestMove = index;
            }
            board_pointer->update_board(index, index, '-'); // Undo move
            if (bestMove != -1) break;
        }

        // Step 2: Try to block the opponent from winning
        if (bestMove == -1) {
            for (int index : indexes) {
                board_pointer->update_board(index, index, opponentSymbol);
                if (board_pointer->is_win()) {
                    bestMove = index;
                }
                board_pointer->update_board(index, index, '-'); // Undo move
                if (bestMove != -1) break;
            }
        }

        // Step 3: Use minimax to find the best move for the future
        if (bestMove == -1) {
            int bestScore = INT_MIN;

            for (int index : indexes) {
                // Simulate the move
                board_pointer->update_board(index, index, aiSymbol);

                // Create updated indexes for recursion
                vector<int> updatedIndexes = indexes;
                updatedIndexes.erase(find(updatedIndexes.begin(), updatedIndexes.end(), index));

                // Recursively evaluate the move using minimax
                int moveScore = minimax(board_pointer, false, aiSymbol, opponentSymbol, INT_MIN, INT_MAX, updatedIndexes);

                // Undo the move
                board_pointer->update_board(index, index, '-');

                // Update the best move
                if (moveScore > bestScore) {
                    bestScore = moveScore;
                    bestMove = index;
                }
            }
        }

        // Perform the chosen move
        if (bestMove != -1) {
            cout << this->getname() << " chooses " << bestMove << endl;
            board_pointer->update_board(bestMove, bestMove, aiSymbol);
            board_pointer->display_board();
            indexes.erase(remove(indexes.begin(), indexes.end(), bestMove), indexes.end());
        }
    }


};

#endif //BOARD_GAMES_HUMAN_PLAYER_H
