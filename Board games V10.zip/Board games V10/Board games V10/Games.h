#include "BoardGame_Classes.h"
#ifndef BOARD_GAMES_PYRAMIC_H
#define BOARD_GAMES_PYRAMIC_H

#include <vector>
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

template<typename T>
class Pyramic_board : public Board<T> {
private:
    vector<pair<int, char>> board; // Flattened board
    static const int levels = 3;

public:
    Pyramic_board() {
        board.clear();
        for (int i = 0; i <= 8; ++i) {
            board.emplace_back(i,'-');
        }
    }

    void display_board() {
        const int cell_width = 6; // Width of each cell
        const int total_width = levels * cell_width + (levels - 1) * cell_width; // Full width of the last level
        int currentIndex = 0;

        for (int i = 0; i < levels; ++i) {
            int numCells = 1 + (i * 2); // Calculate number of cells in the level

            // Calculate padding for alignment
            int padding = (total_width - (numCells * cell_width)) / 2;
            if (i == 1)cout << string(padding + 1, ' ');
            else if (i == 0)cout << string(padding + 2, ' ');
            else cout << string(padding, ' '); // Add left padding

            // Print each cell with separators
            for (int j = 0; j < numCells; ++j) {
                auto [index, symbol] = board[currentIndex++];
                cout << setw(cell_width) << left
                     << (" [" + to_string(index) + "] " + (symbol == ' ' ? "-" : string(1, symbol)));
                if (j < numCells - 1) cout << "|"; // Vertical separator
            }

            cout << "\n";
            if (i == 0) {
                cout << "             --------" << endl;
            } else if (i == 1) {
                cout<<"      -------+------+-------"<<endl;
            }

            else cout << "------+------+------+------+-----" << endl << endl;
        }
    }

    bool is_win() {
        // Hardcoded winning conditions for levels
        if (board[0].second == board[1].second && board[1].second == board[4].second && board[0].second != '-') return true;
        if (board[0].second == board[2].second && board[2].second == board[6].second && board[0].second != '-') return true;
        if (board[0].second == board[3].second && board[3].second == board[8].second && board[0].second != '-') return true;
        if (board[1].second == board[2].second && board[2].second == board[3].second && board[2].second != '-') return true;
        if (board[5].second == board[6].second && board[6].second == board[7].second && board[5].second != '-') return true;
        if (board[6].second == board[7].second && board[7].second == board[8].second && board[6].second != '-') return true;
        if (board[4].second == board[5].second && board[5].second == board[6].second && board[5].second != '-') return true;
        return false;
    }

    bool is_draw() {
        for(auto i:board){
            if(i.second=='-')return false;
        }
        return true;
    }

    bool game_is_over() {
        return is_win() || is_draw();
    }

    void update_board(int x, T symbol) {
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }

    }
    bool update_board(int x,int y,T symbol){
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }
        return true;
    }
};
template<typename T>
class FiveByFiveBoard : public Board<T> {
private:
    vector<vector<T>> board; // 2D vector to represent the 5x5 board
    static const int size = 5; // Size of the board (5x5)

public:

    FiveByFiveBoard() {
        board.resize(size, vector<T>(size, '-'));
    }

    // Method to display the board
    void display_board() {
        // Display column numbers
        cout << "  ";
        for (int col = 0; col < size; ++col) {
            cout << setw(3) << col;
        }
        cout << endl;

        // Display the rows and the cells in each row
        for (int row = 0; row < size; ++row) {
            cout << row << " "; // Display the row number
            for (int col = 0; col < size; ++col) {
                cout << setw(3) << board[row][col]; // Display each cell's value
            }
            cout << endl;
        }
    }

    // Method to check if there is a winner
    bool is_win() {
        int player1ThreeInARow = 0;
        int player2ThreeInARow = 0;

        // Check horizontal rows for three consecutive symbols
        for (int row = 0; row < size; ++row) {
            for (int col = 0; col <= size - 3; ++col) {
                if (board[row][col] != '-' &&
                    board[row][col] == board[row][col + 1] &&
                    board[row][col] == board[row][col + 2]) {
                    if (board[row][col] == 'X') player1ThreeInARow++;
                    else if (board[row][col] == 'O') player2ThreeInARow++;
                }
            }
        }

        // Check vertical columns for three consecutive symbols
        for (int col = 0; col < size; ++col) {
            for (int row = 0; row <= size - 3; ++row) {
                if (board[row][col] != '-' &&
                    board[row][col] == board[row + 1][col] &&
                    board[row][col] == board[row + 2][col]) {
                    if (board[row][col] == 'X') player1ThreeInARow++;
                    else if (board[row][col] == 'O') player2ThreeInARow++;
                }
            }
        }

        // Check diagonal (top-left to bottom-right) for three consecutive symbols
        for (int row = 0; row <= size - 3; ++row) {
            for (int col = 0; col <= size - 3; ++col) {
                if (board[row][col] != '-' &&
                    board[row][col] == board[row + 1][col + 1] &&
                    board[row][col] == board[row + 2][col + 2]) {
                    if (board[row][col] == 'X') player1ThreeInARow++;
                    else if (board[row][col] == 'O') player2ThreeInARow++;
                }
            }
        }

        // Check diagonal (top-right to bottom-left) for three consecutive symbols
        for (int row = 0; row <= size - 3; ++row) {
            for (int col = 2; col < size; ++col) {
                if (board[row][col] != '-' &&
                    board[row][col] == board[row + 1][col - 1] &&
                    board[row][col] == board[row + 2][col - 2]) {
                    if (board[row][col] == 'X') player1ThreeInARow++;
                    else if (board[row][col] == 'O') player2ThreeInARow++;
                }
            }
        }

        // Determine winner based on the number of three-in-a-row sequences
        if (player1ThreeInARow > player2ThreeInARow) return true; // Player 1 wins
        if (player2ThreeInARow > player1ThreeInARow) return true; // Player 2 wins
        return false; // No winner yet
    }

    // Method to check if the game is a draw (board is full)
    bool is_draw() {
        int filledCells = 0;
        for (const auto& row : board) {
            for (const auto& cell : row) {
                if (cell != '-') filledCells++;
            }
        }
        return filledCells == 24; // Check if the board is full (24 moves made, since 1 cell remains empty)
    }

    // Method to update the board with a symbol ('X' or 'O')
    bool update_board(int x, int y, T symbol) {
        if (x < 0 || x >= size || y < 0 || y >= size || board[x][y] != '-') {
            return false;
        }
        board[x][y] = symbol;
        return true;
    }

    // Method to check if the game is over (either a win or a draw)
    bool game_is_over() {
        return is_win() || is_draw(); // Game is over if there's a winner or if it's a draw
    }
};

#endif
