#include "BoardGame_Classes.h"
#ifndef BOARD_GAMES_PYRAMIC_H
#define BOARD_GAMES_PYRAMIC_H

#include <vector>
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

template<typename T>
class Pyramic_board : public Board<T> {
private:
    vector<pair<int, char>> board; // Flattened board
    static const int levels = 3;

public:
    Pyramic_board() {
        board.clear();
        for (int i = 0; i <= 8; ++i) {
            board.emplace_back(i,'-');
        }
    }

    void display_board() {
        const int cell_width = 6; // Width of each cell
        const int total_width = levels * cell_width + (levels - 1) * cell_width; // Full width of the last level
        int currentIndex = 0;

        for (int i = 0; i < levels; ++i) {
            int numCells = 1 + (i * 2); // Calculate number of cells in the level

            // Calculate padding for alignment
            int padding = (total_width - (numCells * cell_width)) / 2;
            if (i == 1)cout << string(padding + 1, ' ');
            else if (i == 0)cout << string(padding + 2, ' ');
            else cout << string(padding, ' '); // Add left padding

            // Print each cell with separators
            for (int j = 0; j < numCells; ++j) {
                auto [index, symbol] = board[currentIndex++];
                cout << setw(cell_width) << left
                     << (" [" + to_string(index) + "] " + (symbol == ' ' ? "-" : string(1, symbol)));
                if (j < numCells - 1) cout << "|"; // Vertical separator
            }

            cout << "\n";
            if (i == 0) {
                cout << "             --------" << endl;
            } else if (i == 1) {
                cout<<"      -------+------+-------"<<endl;
            }

            else cout << "------+------+------+------+-----" << endl << endl;
        }
    }

    bool is_win() {
        // Hardcoded winning conditions for levels
        if (board[0].second == board[1].second && board[1].second == board[4].second && board[0].second != '-') return true;
        if (board[0].second == board[2].second && board[2].second == board[6].second && board[0].second != '-') return true;
        if (board[0].second == board[3].second && board[3].second == board[8].second && board[0].second != '-') return true;
        if (board[1].second == board[2].second && board[2].second == board[3].second && board[2].second != '-') return true;
        if (board[5].second == board[6].second && board[6].second == board[7].second && board[5].second != '-') return true;
        if (board[6].second == board[7].second && board[7].second == board[8].second && board[6].second != '-') return true;
        if (board[4].second == board[5].second && board[5].second == board[6].second && board[5].second != '-') return true;
        return false;
    }

    bool is_draw() {
        for(auto i:board){
            if(i.second=='-')return false;
        }
        return true;
    }

    bool game_is_over() {
        return is_win() || is_draw();
    }

    void update_board(int x, T symbol) {
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }

    }
    bool update_board(int x,int y,T symbol){
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }
        return true;
    }
};
template<typename T>
class FiveByFiveBoard : public Board<T> {
private:
    vector<pair<int, char>> board; // 1D vector to represent the 5x5 board
    static const int size = 5; // Size of the board (5x5)
    int player1ThreeInARow;
    int player2ThreeInARow;
    bool draw=false;

public:
    // Constructor to initialize the board with pairs of (0, '-')
    FiveByFiveBoard() {
        board.clear();
        for (int i = 0; i <= 24; ++i) {
            board.emplace_back(i,'-');
        }
        player1ThreeInARow = 0;
        player2ThreeInARow = 0;
    }

    // Method to display the board
    void display_board() {
        // Display column numbers
        cout << "  ";
        for (int col = 0; col < size; ++col) {
            cout << setw(3) << col;
        }
        cout << endl;

        // Display the rows and the cells in each row
        for (int row = 0; row < size; ++row) {
            cout << row << " "; // Display the row number
            for (int col = 0; col < size; ++col) {
                int index = row * size + col;
                cout << setw(3) << board[index].second; // Display each cell's symbol (second of the pair)
            }
            cout << endl;
        }
    }

    // Method to check if there is a winner
    bool is_win() {
        int notfilled=0;
        for (auto& cell : board) {
            if (cell.second == '-') {
                notfilled++;
            }
            if(notfilled>1)return false;
        }
        // Check horizontal rows for three consecutive symbols
        for (int row = 0; row < size; ++row) {
            for (int col = 0; col <= size - 3; ++col) {
                int index1 = row * size + col;
                int index2 = row * size + col + 1;
                int index3 = row * size + col + 2;
                if (board[index1].second != '-' &&
                    board[index1].second == board[index2].second &&
                    board[index1].second == board[index3].second) {
                    if (board[index1].second == 'X') player1ThreeInARow++;
                    else if (board[index1].second == 'O') player2ThreeInARow++;
                }
            }
        }

        // Check vertical columns for three consecutive symbols
        for (int col = 0; col < size; ++col) {
            for (int row = 0; row <= size - 3; ++row) {
                int index1 = row * size + col;
                int index2 = (row + 1) * size + col;
                int index3 = (row + 2) * size + col;
                if (board[index1].second != '-' &&
                    board[index1].second == board[index2].second &&
                    board[index1].second == board[index3].second) {
                    if (board[index1].second == 'X') player1ThreeInARow++;
                    else if (board[index1].second == 'O') player2ThreeInARow++;
                }
            }
        }

        // Check diagonal (top-left to bottom-right) for three consecutive symbols
        for (int row = 0; row <= size - 3; ++row) {
            for (int col = 0; col <= size - 3; ++col) {
                int index1 = row * size + col;
                int index2 = (row + 1) * size + (col + 1);
                int index3 = (row + 2) * size + (col + 2);
                if (board[index1].second != '-' &&
                    board[index1].second == board[index2].second &&
                    board[index1].second == board[index3].second) {
                    if (board[index1].second == 'X') player1ThreeInARow++;
                    else if (board[index1].second == 'O') player2ThreeInARow++;
                }
            }
        }

        // Check diagonal (top-right to bottom-left) for three consecutive symbols
        for (int row = 0; row <= size - 3; ++row) {
            for (int col = 2; col < size; ++col) {
                int index1 = row * size + col;
                int index2 = (row + 1) * size + (col - 1);
                int index3 = (row + 2) * size + (col - 2);
                if (board[index1].second != '-' &&
                    board[index1].second == board[index2].second &&
                    board[index1].second == board[index3].second) {
                    if (board[index1].second == 'X') player1ThreeInARow++;
                    else if (board[index1].second == 'O') player2ThreeInARow++;
                }
            }
        }

        // Determine winner based on the number of three-in-a-row sequences
        if (player1ThreeInARow > player2ThreeInARow) return true; // Player 1 wins
        if (player2ThreeInARow > player1ThreeInARow) return true; // Player 2 wins
        else {
            draw= true;
            return false; // No winner yet
        }
    }

    // Method to check if the game is a draw (board is full)
    bool is_draw() {
        if(draw)return true;
        else return false;
    }

    // Method to update the board with a symbol ('X' or 'O')
    bool update_board(int x, int y, T symbol) {
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }
        return true;
    }

    // Method to check if the game is over (either a win or a draw)
    bool game_is_over() {
        return is_win() || is_draw(); // Game is over if there's a winner or if it's a draw
    }
};

#endif
