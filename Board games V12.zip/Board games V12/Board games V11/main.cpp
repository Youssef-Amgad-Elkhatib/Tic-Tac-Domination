#include <bits/stdc++.h>
#include "BoardGame_Classes.h"
#include "MinMaxPlayer.h"
#include "Games.h"
#include "All_Players.h"
#include "Gaming.h"
using namespace std;
#define ll long long

string menu(){
    cout<<"           <<<<<Welcome to our gaming application>>>>>"<<endl<<endl;
    cout<<"*Choose your desired game*"<<endl;
    cout<<"1. Pyramic Tic-Tac-Toe          ";
    cout<<"2. Connect 4"<<endl;
    cout<<"3. 5x5 Tic-Tac-Toe              ";
    cout<<"4. Word Tic-Tac-Toe"<<endl;
    cout<<"5. Numerical Tic-Tac-Toe        ";
    cout<<"6. Misere Tic-Tac-Toe"<<endl;
    cout<<"7. Ultimate Tic-Tac-Toe         ";
    cout<<"8. SUS"<<endl;
    cout<<"9. Exit"<<endl;
    string choice;
    cin>>choice;
    while(true){
        if(choice!="1"&& choice!="2"&& choice!="3"&&choice!="4"&&choice!="5"&&choice!="6"&&choice!="7"&&choice!="8"&&
                choice!="9")
        {
            cout<<"Please enter a valid choice"<<endl;
            cin>>choice;
        }
        else break;
    }
    return choice;
}

string sub_menu(){
    cout<<"1. Human"<<endl;
    cout<<"2. Normal Computer"<<endl;
    cout<<"3. AI"<<endl;
    string choice;
    cin>>choice;
    while(true) {
        if(choice != "1" && choice != "2" && choice != "3")
        {
            cout << "Please enter a valid choice" << endl;
            cin >> choice;
        }
        else break;
    }
    return choice;
}

void pyramic(string& choice1,string& choice2,string& name1,string& name2){
    if(choice1=="1"&& choice2=="1"){
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Human_Player<char> player1(name1, 'X', board_pointer);
        Human_Player<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, false);
    }
    else if(choice1=="1"&& choice2=="2"){
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Human_Player<char> player1(name1, 'X', board_pointer);
        Computer_Player<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, false);
    }
    else if(choice1=="1"&& choice2=="3"){
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Human_Player<char> player1(name1, 'X', board_pointer);
        AI<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, false);
    }
    else if(choice1=="2"&& choice2=="1"){
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Human_Player<char> player1(name2, 'X', board_pointer);
        Computer_Player<char> player2(name1, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player2, &player1 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, false);
    }
    else if(choice1=="2"&& choice2=="2"){
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Computer_Player<char> player1(name1, 'X',board_pointer );
        Computer_Player<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, false);
    }
    else if(choice1=="2"&& choice2=="3") {
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Computer_Player<char> player1(name1, 'X',board_pointer );
        AI<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, false);
    }
    else if(choice1=="3"&& choice2=="1"){
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Human_Player<char> player1(name2, 'X', board_pointer);
        AI<char> player2(name1, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player2, &player1 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, false);
    }
    else if(choice1=="3"&& choice2=="2"){
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Computer_Player<char> player1(name2, 'X', board_pointer);
        AI<char> player2(name1, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player2, &player1 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, false);
    }
    else{
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        AI<char> player1(name1, 'X', board_pointer);
        AI<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, false);
    }
}

void playFourInARow(string &choice1 , string &choice2 , string &name1 , string &name2){
    if(choice1=="1"&& choice2=="1") {
        FourInARow<char> connectfour;
        Board<char> *board_pointer = &connectfour;
        Human_Player<char> player1(name1, 'X', board_pointer);
        Human_Player<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char> *players[] = {&player1, &player2};

        // Initialize valid move indexes
        vector<int> indexes =  { 0, 1, 2, 3, 4, 5, 6 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, false);
    }
    else if(choice1=="1"&& choice2=="2"){
        FourInARow<char> connectfour;
        Board<char>* board_pointer=&connectfour;
        // Initialize players
        Human_Player<char> player1(name1, 'X', board_pointer);
        Computer_Player<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes =  { 0, 1, 2, 3, 4, 5, 6 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, false);
    }
    else if(choice1=="1"&& choice2=="3"){

    }
    else if(choice1=="2"&& choice2=="1"){
        FourInARow<char> connectfour;
        Board<char>* board_pointer=&connectfour;
        // Initialize players
        Human_Player<char> player1(name2, 'X', board_pointer);
        Computer_Player<char> player2(name1, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player2, &player1 };

        // Initialize valid move indexes
        vector<int> indexes =  { 0, 1, 2, 3, 4, 5, 6 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, false);
    }
    else if(choice1=="2"&& choice2=="2"){
        FourInARow<char> connectfour;
        Board<char>* board_pointer=&connectfour;
        // Initialize players
        Computer_Player<char> player1(name1, 'X',board_pointer );
        Computer_Player<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, false);
    }
    else if(choice1=="2"&& choice2=="3") {

    }
    else if(choice1=="3"&& choice2=="1"){

    }
    else if(choice1=="3"&& choice2=="2"){

    }
    else{

    }

}

void five_by_five(string& choice1, string& choice2, string& name1, string& name2) {
    if (choice1 == "1" && choice2 == "1") {
        FiveByFiveBoard<char> fiveByFiveBoard;
        Board<char>* board_pointer = &fiveByFiveBoard;
        // Initialize players
        Human_Player<char> player1(name1, 'X', board_pointer);
        Human_Player<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

         game.run_game(false, false);
    }
    else if (choice1 == "1" && choice2 == "2") {
        FiveByFiveBoard<char> fiveByFiveBoard;
        Board<char>* board_pointer = &fiveByFiveBoard;

        Human_Player<char> player1(name1, 'X', board_pointer);
        Computer_Player<char> player2(name2, 'O', board_pointer);


        Player<char>* players[] = { &player1, &player2 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };

        Gaming<char> game(board_pointer, players, indexes);

         game.run_game(false, false);
    }
    else if (choice1 == "1" && choice2 == "3") {
        FiveByFiveBoard<char> fiveByFiveBoard;
        Board<char>* board_pointer = &fiveByFiveBoard;
        // Initialize players
        Human_Player<char> player1(name1, 'X', board_pointer);
        AI<char> player2(name2, 'O', board_pointer);

        Player<char>* players[] = { &player1, &player2 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };
        Gaming<char> game(board_pointer, players, indexes);

         game.run_game(false, false);
    }
    else if (choice1 == "2" && choice2 == "1") {
        FiveByFiveBoard<char> fiveByFiveBoard;
        Board<char>* board_pointer = &fiveByFiveBoard;

        Human_Player<char> player1(name2, 'X', board_pointer);
        Computer_Player<char> player2(name1, 'O', board_pointer);


        Player<char>* players[] = { &player2, &player1 };


        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };

        Gaming<char> game(board_pointer, players, indexes);

         game.run_game(false, false);
    }
    else if (choice1 == "2" && choice2 == "2") {
        FiveByFiveBoard<char> fiveByFiveBoard;
        Board<char>* board_pointer = &fiveByFiveBoard;

        Computer_Player<char> player1(name1, 'X', board_pointer);
        Computer_Player<char> player2(name2, 'O', board_pointer);

        Player<char>* players[] = { &player1, &player2 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };

        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false);
    }
    else if (choice1 == "2" && choice2 == "3") {
        FiveByFiveBoard<char> fiveByFiveBoard;
        Board<char>* board_pointer = &fiveByFiveBoard;
        // Initialize players
        Computer_Player<char> player1(name1, 'X', board_pointer);
        AI<char> player2(name2, 'O', board_pointer);

        Player<char>* players[] = { &player1, &player2 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };

        Gaming<char> game(board_pointer, players, indexes);

         game.run_game(false, false);
    }
    else if (choice1 == "3" && choice2 == "1") {
        FiveByFiveBoard<char> fiveByFiveBoard;
        Board<char>* board_pointer = &fiveByFiveBoard;

        Human_Player<char> player1(name2, 'X', board_pointer);
        AI<char> player2(name1, 'O', board_pointer);

        Player<char>* players[] = { &player2, &player1 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };

        Gaming<char> game(board_pointer, players, indexes);

         game.run_game(false, false);
    }
    else if (choice1 == "3" && choice2 == "2") {
        FiveByFiveBoard<char> fiveByFiveBoard;
        Board<char>* board_pointer = &fiveByFiveBoard;

        Computer_Player<char> player1(name2, 'X', board_pointer);
        AI<char> player2(name1, 'O', board_pointer);

        Player<char>* players[] = { &player2, &player1 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };

        Gaming<char> game(board_pointer, players, indexes);

         game.run_game(false, false);
    }
    else {
        FiveByFiveBoard<char> fiveByFiveBoard;
        Board<char>* board_pointer = &fiveByFiveBoard;

        AI<char> player1(name1, 'X', board_pointer);
        AI<char> player2(name2, 'O', board_pointer);

        Player<char>* players[] = { &player1, &player2 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };

        Gaming<char> game(board_pointer, players, indexes);

         game.run_game(false, false);
    }
 }
int main(){

    string choice=menu();
    if(choice=="9"){
        cout<<"Thanks for using our application"<<endl;
        exit(0);
    }

    cout<<"Choose Player 1 name"<<endl;
    string name1;
    cin>>name1;
    cout<<"Choose type of player 1"<<endl;
    string sub_choice_1=sub_menu();

    cout<<"Choose Player 2 name"<<endl;
    string name2;
    cin>>name2;
    cout<<"Choose type of player 2"<<endl;
    string sub_choice_2=sub_menu();

    switch (stoi(choice)) {
        case 1:
            pyramic(sub_choice_1,sub_choice_2,name1,name2);
            break;
        case 2:
            playFourInARow(sub_choice_1 , sub_choice_2 , name1 , name2);
            break;
        case 3:
            five_by_five(sub_choice_1,sub_choice_2,name1,name2);
            break;
        default:
            break;
    }
    main();
}


