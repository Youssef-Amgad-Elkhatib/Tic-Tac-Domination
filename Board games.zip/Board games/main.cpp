#include <bits/stdc++.h>
#include "BoardGame_Classes.h"
#include "MinMaxPlayer.h"
#include "Pyramic.h"
#include "Human_Player.h"
using namespace std;
#define ll long long

string menu(){
    cout<<"           <<<<<Welcome to our gaming application>>>>>"<<endl<<endl;
    cout<<"*Choose your desired game*"<<endl;
    cout<<"1. Pyramic Tic-Tac-Toe          ";
    cout<<"2. Connect 4"<<endl;
    cout<<"3. 5x5 Tic-Tac-Toe              ";
    cout<<"4. Word Tic-Tac-Toe"<<endl;
    cout<<"5. Numerical Tic-Tac-Toe        ";
    cout<<"6. Misere Tic-Tac-Toe"<<endl;
    cout<<"7. Ultimate Tic-Tac-Toe         ";
    cout<<"8. SUS"<<endl;
    cout<<"9. Exit"<<endl;
    string choice;
    cin>>choice;
    while(true){
        if(choice!="1"&& choice!="2"&& choice!="3"&&choice!="4"&&choice!="5"&&choice!="6"&&choice!="7"&&choice!="8"&&
                choice!="9")
        {
            cout<<"Please enter a valid choice"<<endl;
            cin>>choice;
        }
        else break;
    }
    return choice;
}

string sub_menu(){
    cout<<"1. Human"<<endl;
    cout<<"2. Normal Computer"<<endl;
    cout<<"3. AI"<<endl;
    string choice;
    cin>>choice;
    while(true) {
        if(choice != "1" && choice != "2" && choice != "3")
        {
            cout << "Please enter a valid choice" << endl;
            cin >> choice;
        }
        else break;
    }
    return choice;
}
bool validate_index(string index){
    if(index!="1"&& index!="2"&&index!="0"&& index!="3"&& index!="4"&& index!="5"&& index!="6" && index!="7"&&index!="8")return false;
    return true;
}
void pyramic(string& choice1,string& choice2,string& name1,string& name2){
    if(choice1=="1"&& choice2=="1"){
        Pyramic_board<char> p;
        Human_Player<char> p1(name1,'X',p);
        Human_Player<char> p2(name2,'O',p);
        vector<int> indexes{0,1,2,3,4,5,6,7,8};
        bool flag=true;
        while(true){
            if(p.is_win()){
                cout<<name2<<" WINS"<<endl;
                break;
            }
            if(p.is_draw()){
                cout<<"It is a DRAW"<<endl;
                break;
            }
            if(flag){
                p.display_board();
                flag= false;
            }
            cout<<name1+"'s"<<" turn"<<endl;
            cout<<"Please enter index"<<endl;
            string index;
            cin>>index;
            auto it=find(indexes.begin(),indexes.end(),stoi(index));
            while (true){
                if(!validate_index(index) || it==indexes.end()){
                    cout<<"Please enter a valid index (not chosen before)"<<endl;
                    cin>>index;
                    it=find(indexes.begin(),indexes.end(),stoi(index));
                }
                else break;
            }
            int x= stoi(index);
            indexes.erase(it);
            p1.getmove(x);
            if(p.is_win()){
                cout<<name1<<" WINS"<<endl;
                break;
            }
            if(p.is_draw()){
                cout<<"It is a DRAW"<<endl;
                break;
            }
            cout<<name2+"'s"<<" turn"<<endl;
            cout<<"Please enter index"<<endl;
            cin>>index;
            it=find(indexes.begin(),indexes.end(),stoi(index));
            while (true){
                if(!validate_index(index) || it==indexes.end()){
                    cout<<"Please enter a valid index (not chosen before)"<<endl;
                    cin>>index;
                    it=find(indexes.begin(),indexes.end(),stoi(index));
                }
                else break;
            }
            x= stoi(index);
            indexes.erase(it);
            p2.getmove(x);
        }
    }
    else if(choice1=="1"&& choice2=="2"){

    }
    else if(choice1=="1"&& choice2=="3"){

    }
    else if(choice1=="2"&& choice2=="1"){

    }
    else if(choice1=="2"&& choice2=="2"){

    }
    else if(choice1=="2"&& choice2=="3") {

    }
    else if(choice1=="3"&& choice2=="1"){

    }
    else if(choice1=="3"&& choice2=="2"){

    }
    else{

    }
}
int main(){

    string choice=menu();
    if(choice=="9"){
        cout<<"Thanks for using our application"<<endl;
        exit(0);
    }

    cout<<"Choose Player 1 name"<<endl;
    string name1;
    cin>>name1;
    cout<<"Choose type of player 1"<<endl;
    string sub_choice_1=sub_menu();

    cout<<"Choose Player 2 name"<<endl;
    string name2;
    cin>>name2;
    cout<<"Choose type of player 2"<<endl;
    string sub_choice_2=sub_menu();

    switch (stoi(choice)) {
        case 1:
            pyramic(sub_choice_1,sub_choice_2,name1,name2);
            break;
        default:
            break;
    }
    main();
}


