#include "BoardGame_Classes.h"
#ifndef BOARD_GAMES_PYRAMIC_H
#define BOARD_GAMES_PYRAMIC_H

template<typename T>
class Pyramic_board: public Board<T>{
private:
    vector<vector<pair<int, char>>> board;
    static const int levels = 3;

public:
    Pyramic_board(){
        int index = 0;
        for (int i = 0; i < levels; ++i) {
            board.emplace_back();
            int numCells = 1 + (i * 2); // 1, 3, 5 for levels 0, 1, 2
            for (int j = 0; j < numCells; ++j) {
                board[i].emplace_back(index++, ' '); // Index starts at 0, symbol is empty
            }
        }
    }
void display_board(){
    const int cell_width = 6; // Width of each cell
    const int total_width = levels * cell_width + (levels - 1) * cell_width; // Full width of the last level

    for (int i = 0; i < levels; ++i) {
        int numCells = 1 + (i * 2); // Calculate number of cells in the level

        // Calculate padding for alignment
        int padding = (total_width - (numCells * cell_width)) / 2;
        cout << string(padding, ' '); // Add left padding

        // Print each cell with separators
        for (int j = 0; j < numCells; ++j) {
            auto [index, symbol] = board[i][j];
            cout << setw(cell_width) << left << (" [" + to_string(index) + "] " + (symbol == ' ' ? "-" : string(1, symbol)));
            if (j < numCells - 1) cout << "|"; // Vertical separator
        }

        cout << "\n";

        // Print horizontal separator between levels
        if (i < levels - 1) {
            cout << string(padding, ' '); // Add left padding for separator
            for (int j = 0; j < numCells; ++j) {
                cout << string(cell_width, '-') << (j < numCells - 1 ? "+" : "");
            }
            cout << "\n";
        }
    }
    cout<<"------+------+------+------+-----"<<endl<<endl;

}
void increment(){
        this->n_moves++;
    }
bool is_win(){
if(board[0][0].second==board[1][0].second && board[2][0].second==board[0][0].second && board[0][0].second!='-'){
    return true;
}
else if(board[0][0].second==board[1][2].second && board[2][4].second==board[0][0].second && board[0][0].second!='-'){
    return true;
}
else if(board[1][0].second==board[1][1].second && board[1][1].second==board[1][2].second && board[1][0].second!='-'){
    return true;
}
else if(board[0][0].second==board[1][1].second && board[2][2].second==board[1][1].second && board[0][0].second!='-'){
    return true;
}
else if(board[2][0].second==board[2][1].second && board[2][1].second==board[2][2].second && board[2][0].second!='-'){
    return true;
}
else if(board[2][1].second==board[2][2].second && board[2][2].second==board[2][3].second && board[2][2].second!='-'){
    return true;
}
else if(board[2][2].second==board[2][3].second && board[2][3].second==board[2][4].second && board[2][2].second!='-'){
    return true;
}
    return false;
}

bool is_draw(){
if(!is_win() && this->n_moves==9){
    return true;
}
}
bool game_is_over(){
    if(is_win() || is_draw())return true;
}
bool update_board(int x,int y,T symbol){
    for (auto& row : board) {
        for (auto& cell : row) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }
    }
}
};
template<class T>
class Pyramic_player:public Player<T>{
    Pyramic_board<char> b;
public:
    Pyramic_player(string x,T sym,Pyramic_board<char>&c): Player<T>(x,sym){b=c;this->setBoard(&b);}
    void getmove(int& x, int& y){
        b.update_board(x,y,this->symbol);
        b.increment();
        b.display_board();
    }
};


#endif //BOARD_GAMES_PYRAMIC_H
