#ifndef BOARD_GAMES_GAMING_H
#define BOARD_GAMES_GAMING_H
#include "BoardGame_Classes.h"
#include "All_Players.h"
template<class T>
class Gaming{
private:
    vector<int> indexes;
    Board<T>* board_pointer;
    Player<T>* gaming_players[2];
    vector<char> alphabet{'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    vector<char> odd_numbers{'1','3','5','7','9'};
    vector<char> even_numbers{'2','4','6','8'};
public:
    Gaming(Board<T>* b, Player<T>* playerPtr[2], vector<int>& v)
    {
        board_pointer=b;
        gaming_players[0]=playerPtr[0];
        gaming_players[1]=playerPtr[1];
        indexes=v;
    }

    void run_game(bool pyramic,bool connect4,bool fivebyfive,bool word,bool number,bool misere,bool ultimate,bool sus) {
        bool flag = true;

        while (true) {
            // Check if the game is over
            if (this->board_pointer->is_win()) {
                if (misere) {
                    cout << this->gaming_players[0]->getname() << " WINS\n";
                } else {
                    cout << this->gaming_players[1]->getname() << " WINS\n";
                }
                break;
            }
            if (this->board_pointer->is_draw()) {
                cout << "It is a DRAW" << endl;
                break;
            }

            // Display the board on the first iteration
            if (flag) {
                this->board_pointer->display_board();
                flag = false;
            }

            // Loop through both players
            for (int i = 0; i < 2; ++i) {
                cout << this->gaming_players[i]->getname() << "'s turn" << endl;

                // Check if the player is a computer
                if (auto* compPlayer = dynamic_cast<Computer_Player<T>*>(this->gaming_players[i])) {
                    if(number && i==0){
                        compPlayer->setsymbol(odd_numbers,number);
                    }
                    if(number && i==1){
                        compPlayer->setsymbol(even_numbers,number);
                    }
                    if(word)compPlayer->setsymbol(alphabet, false);
                    compPlayer->make_move(indexes, this->board_pointer,connect4);
                }
                else if (auto* aiPlayer = dynamic_cast<Pyramic_AI<T>*>(this->gaming_players[i])) {
                    aiPlayer->make_move(indexes, this->gaming_players, this->board_pointer);
                }
               /* else if (auto* aiPlayer = dynamic_cast<Numerical_AI<T>*>(this->gaming_players[i])) {
                    aiPlayer->make_move(indexes, this->gaming_players, this->board_pointer);
                }*/

                else {
                    if (auto* humanPlayer = dynamic_cast<Human_Player<T>*>(this->gaming_players[i])) {
                        if(i==0 && number){
                            humanPlayer->setsymbol(odd_numbers,number);
                        }
                        else if(i==1 && number){
                            humanPlayer->setsymbol(even_numbers,number);
                        }
                        if(word)humanPlayer->setsymbol(alphabet, false);
                        humanPlayer->make_move(indexes, this->board_pointer,connect4);
                    }

                }

                // Check for win or draw
                if (this->board_pointer->is_win()) {
                    if (misere) {
                        cout << this->gaming_players[1 - i]->getname() << " WINS\n";
                    } else {
                        cout << this->gaming_players[i]->getname() << " WINS\n";
                    }
                    return;
                }
                if (this->board_pointer->is_draw()) {
                    cout << "It is a DRAW" << endl;
                    return;
                }
            }
        }
    }

};


#endif //BOARD_GAMES_GAMING_H