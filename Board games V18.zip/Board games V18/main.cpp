#include <bits/stdc++.h>
#include "BoardGame_Classes.h"
#include "MinMaxPlayer.h"
#include "Games.h"
#include "All_Players.h"
#include "Gaming.h"

using namespace std;
#define ll long long
void manager();
string menu(){
    cout<<"           <<<<<Welcome to our gaming application>>>>>"<<endl<<endl;
    cout<<"*Choose your desired game*"<<endl;
    cout<<"1. Pyramic Tic-Tac-Toe          ";
    cout<<"2. Connect 4"<<endl;
    cout<<"3. 5x5 Tic-Tac-Toe              ";
    cout<<"4. Word Tic-Tac-Toe"<<endl;
    cout<<"5. Numerical Tic-Tac-Toe        ";
    cout<<"6. Misere Tic-Tac-Toe"<<endl;
    cout<<"7. Ultimate Tic-Tac-Toe         ";
    cout<<"8. SUS"<<endl;
    cout<<"9. Exit"<<endl;
    string choice;
    cin>>choice;
    while(true){
        if(choice!="1"&& choice!="2"&& choice!="3"&&choice!="4"&&choice!="5"&&choice!="6"&&choice!="7"&&choice!="8"&&
           choice!="9")
        {
            cout<<"Please enter a valid choice"<<endl;
            cin>>choice;
        }
        else break;
    }
    return choice;
}

string sub_menu(){
    cout<<"1. Human"<<endl;
    cout<<"2. Normal Computer"<<endl;
    cout<<"3. AI"<<endl;
    string choice;
    cin>>choice;
    while(true) {
        if(choice != "1" && choice != "2" && choice != "3")
        {
            cout << "Please enter a valid choice" << endl;
            cin >> choice;
        }
        else break;
    }
    return choice;
}

void pyramic(string& choice1,string& choice2,string& name1,string& name2){
    if(choice1=="1"&& choice2=="1"){
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Human_Player<char> player1(name1, 'X', board_pointer);
        Human_Player<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(true, false, false, false, false, false,false,false);
    }
    else if(choice1=="1"&& choice2=="2"){
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Human_Player<char> player1(name1, 'X', board_pointer);
        Computer_Player<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(true, false, false, false, false, false,false,false);
    }
    else if(choice1=="1"&& choice2=="3"){
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Human_Player<char> player1(name1, 'X', board_pointer);
        Pyramic_AI<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(true, false, false, false, false, false,false,false);
    }
    else if(choice1=="2"&& choice2=="1"){
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Human_Player<char> player1(name2, 'X', board_pointer);
        Computer_Player<char> player2(name1, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player2, &player1 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(true, false, false, false, false, false,false,false);
    }
    else if(choice1=="2"&& choice2=="2"){
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Computer_Player<char> player1(name1, 'X',board_pointer );
        Computer_Player<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(true, false, false, false, false, false,false,false);
    }
    else if(choice1=="2"&& choice2=="3") {
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Computer_Player<char> player1(name1, 'X',board_pointer );
        Pyramic_AI<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(true, false, false, false, false, false,false,false);
    }
    else if(choice1=="3"&& choice2=="1"){
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Human_Player<char> player1(name2, 'X', board_pointer);
        Pyramic_AI<char> player2(name1, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player2, &player1 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(true, false, false, false, false, false,false,false);
    }
    else if(choice1=="3"&& choice2=="2"){
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Computer_Player<char> player1(name2, 'X', board_pointer);
        Pyramic_AI<char> player2(name1, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player2, &player1 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(true, false, false, false, false, false,false,false);
    }
    else{
        Pyramic_board<char> pyramicBoard;
        Board<char>* board_pointer=&pyramicBoard;
        // Initialize players
        Pyramic_AI<char> player1(name1, 'X', board_pointer);
        Pyramic_AI<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(true, false, false, false, false, false,false,false);
    }
}

void playFourInARow(string &choice1 , string &choice2 , string &name1 , string &name2){
    if(choice1=="1"&& choice2=="1") {
        FourInARow<char> connectfour;
        Board<char> *board_pointer = &connectfour;
        Human_Player<char> player1(name1, 'X', board_pointer);
        Human_Player<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char> *players[] = {&player1, &player2};

        // Initialize valid move indexes
        vector<int> indexes =  { 0, 1, 2, 3, 4, 5, 6 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, true, false, false, false, false,false,false);
    }
    else if(choice1=="1"&& choice2=="2"){
        FourInARow<char> connectfour;
        Board<char>* board_pointer=&connectfour;
        // Initialize players
        Human_Player<char> player1(name1, 'X', board_pointer);
        Computer_Player<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes =  { 0, 1, 2, 3, 4, 5, 6 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, true, false, false, false, false,false,false);
    }
    else if(choice1=="1"&& choice2=="3"){

    }
    else if(choice1=="2"&& choice2=="1"){
        FourInARow<char> connectfour;
        Board<char>* board_pointer=&connectfour;
        // Initialize players
        Human_Player<char> player1(name2, 'X', board_pointer);
        Computer_Player<char> player2(name1, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player2, &player1 };

        // Initialize valid move indexes
        vector<int> indexes =  { 0, 1, 2, 3, 4, 5, 6 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, true, false, false, false, false,false,false);
    }
    else if(choice1=="2"&& choice2=="2"){
        FourInARow<char> connectfour;
        Board<char>* board_pointer=&connectfour;
        // Initialize players
        Computer_Player<char> player1(name1, 'X',board_pointer );
        Computer_Player<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        // Run the game
        game.run_game(false, true, false, false, false, false,false,false);
    }
    else if(choice1=="2"&& choice2=="3") {

    }
    else if(choice1=="3"&& choice2=="1"){

    }
    else if(choice1=="3"&& choice2=="2"){

    }
    else{

    }

}

void five_by_five(string& choice1, string& choice2, string& name1, string& name2) {
    if (choice1 == "1" && choice2 == "1") {
        FiveByFiveBoard<char> fiveByFiveBoard;
        Board<char>* board_pointer = &fiveByFiveBoard;
        // Initialize players
        Human_Player<char> player1(name1, 'X', board_pointer);
        Human_Player<char> player2(name2, 'O', board_pointer);

        // Store pointers to the players in an array
        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false, true, false, false, false,false,false);
    }
    else if (choice1 == "1" && choice2 == "2") {
        FiveByFiveBoard<char> fiveByFiveBoard;
        Board<char>* board_pointer = &fiveByFiveBoard;

        Human_Player<char> player1(name1, 'X', board_pointer);
        Computer_Player<char> player2(name2, 'O', board_pointer);


        Player<char>* players[] = { &player1, &player2 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };

        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false, true, false, false, false,false,false);
    }
    else if (choice1 == "1" && choice2 == "3") {

    }
    else if (choice1 == "2" && choice2 == "1") {
        FiveByFiveBoard<char> fiveByFiveBoard;
        Board<char>* board_pointer = &fiveByFiveBoard;

        Human_Player<char> player1(name2, 'X', board_pointer);
        Computer_Player<char> player2(name1, 'O', board_pointer);


        Player<char>* players[] = { &player2, &player1 };


        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };

        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false, true, false, false, false,false,false);
    }
    else if (choice1 == "2" && choice2 == "2") {
        FiveByFiveBoard<char> fiveByFiveBoard;
        Board<char>* board_pointer = &fiveByFiveBoard;

        Computer_Player<char> player1(name1, 'X', board_pointer);
        Computer_Player<char> player2(name2, 'O', board_pointer);

        Player<char>* players[] = { &player1, &player2 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };

        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false, true, false, false, false,false,false);
    }
    else if (choice1 == "2" && choice2 == "3") {

    }
    else if (choice1 == "3" && choice2 == "1") {

    }
    else if (choice1 == "3" && choice2 == "2") {

    }
    else {

    }
}

void misere_tic_tac_toe(string& choice1, string& choice2, string& name1, string& name2) {
    if (choice1 == "1" && choice2 == "1") {
        MisereTicTacToe<char> misereTicTacToeBoard;
        Board<char>* board_pointer = &misereTicTacToeBoard;

        Human_Player<char> player1(name1, 'X', board_pointer);
        Human_Player<char> player2(name2, 'O', board_pointer);

        Player<char>* players[] = { &player1, &player2 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false, false, false, false, true, false, false);
    }
    else if (choice1 == "1" && choice2 == "2") {
        MisereTicTacToe<char> misereTicTacToeBoard;
        Board<char>* board_pointer = &misereTicTacToeBoard;

        Human_Player<char> player1(name1, 'X', board_pointer);
        Computer_Player<char> player2(name2, 'O', board_pointer);

        Player<char>* players[] = { &player1, &player2 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false, false, false, false, true, false, false);
    }
    else if (choice1 == "1" && choice2 == "3") {
    }
    else if (choice1 == "2" && choice2 == "1") {
        MisereTicTacToe<char> misereTicTacToeBoard;
        Board<char>* board_pointer = &misereTicTacToeBoard;

        Human_Player<char> player1(name2, 'X', board_pointer);
        Computer_Player<char> player2(name1, 'O', board_pointer);

        Player<char>* players[] = { &player2, &player1 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false, false, false, false, true, false, false);
    }
    else if (choice1 == "2" && choice2 == "2") {
        MisereTicTacToe<char> misereTicTacToeBoard;
        Board<char>* board_pointer = &misereTicTacToeBoard;

        Computer_Player<char> player1(name1, 'X', board_pointer);
        Computer_Player<char> player2(name2, 'O', board_pointer);

        Player<char>* players[] = { &player1, &player2 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false, false, false, false, true, false, false);
    }
    else if (choice1 == "2" && choice2 == "3") {

    }
    else if (choice1 == "3" && choice2 == "1") {

    }
    else if (choice1 == "3" && choice2 == "2") {

    }
    else {

    }
}

void sus_game(string& choice1, string& choice2, string& name1, string& name2) {
    if (choice1 == "1" && choice2 == "1") {
        SUS<char> susBoard;
        Board<char>* board_pointer = &susBoard;

        // Initialize players
        Human_Player<char> player1(name1, 'S', board_pointer);
        Human_Player<char> player2(name2, 'U', board_pointer);

        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false, false, false, false, false, false, true);  // Adjust game flags as needed
    }

    else if (choice1 == "1" && choice2 == "2") {
        SUS<char> susBoard;
        Board<char>* board_pointer = &susBoard;

        Human_Player<char> player1(name1, 'S', board_pointer);
        Computer_Player<char> player2(name2, 'U', board_pointer);

        Player<char>* players[] = { &player1, &player2 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false, false, false, false, false, false, true);
    }

    else if (choice1 == "1" && choice2 == "3") {
        cout<<"There is no AI for this game"<<endl;
        cout<<"Returning to main menu"<<endl;
        manager();
    }

    else if (choice1 == "2" && choice2 == "1") {
        SUS<char> susBoard;
        Board<char>* board_pointer = &susBoard;

        Human_Player<char> player1(name2, 'S', board_pointer);
        Computer_Player<char> player2(name1, 'U', board_pointer);

        Player<char>* players[] = { &player2, &player1 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false, false, false, false, false, false, true);
    }

    else if (choice1 == "2" && choice2 == "2") {
        SUS<char> susBoard;
        Board<char>* board_pointer = &susBoard;

        Computer_Player<char> player1(name1, 'S', board_pointer);
        Computer_Player<char> player2(name2, 'U', board_pointer);

        Player<char>* players[] = { &player1, &player2 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false, false, false, false, false, false, true);
    }
    else if (choice1 == "2" && choice2 == "3") {
        cout<<"There is no AI for this game"<<endl;
        cout<<"Returning to main menu"<<endl;
        manager();
    }
    else if (choice1 == "3" && choice2 == "1") {
        cout<<"There is no AI for this game"<<endl;
        cout<<"Returning to main menu"<<endl;
        manager();
    }
    else if (choice1 == "3" && choice2 == "2") {
        cout<<"There is no AI for this game"<<endl;
        cout<<"Returning to main menu"<<endl;
        manager();
    }
    else {
        cout<<"There is no AI for this game"<<endl;
        cout<<"Returning to main menu"<<endl;
        manager();
    }
}

void word_tic_tac_toe(string choice1,string choice2,string name1,string name2){
    if (choice1 == "1" && choice2 == "1") {
        Word_Board<char> wordBoard;
        Board<char>* board_pointer = &wordBoard;

        // Initialize players
        Human_Player<char> player1(name1, 'S', board_pointer);
        Human_Player<char> player2(name2, 'U', board_pointer);

        Player<char>* players[] = { &player1, &player2 };

        // Initialize valid move indexes
        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        // Create the Gaming instance
        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false, false, true, false, false, false, false);  // Adjust game flags as needed
    }

    else if (choice1 == "1" && choice2 == "2") {
        Word_Board<char> wordBoard;
        Board<char>* board_pointer = &wordBoard;

        Human_Player<char> player1(name1, 'S', board_pointer);
        Computer_Player<char> player2(name2, 'U', board_pointer);

        Player<char>* players[] = { &player1, &player2 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false, false, true, false, false, false, false);
    }

    else if (choice1 == "1" && choice2 == "3") {
    }

    else if (choice1 == "2" && choice2 == "1") {
        Word_Board<char> wordBoard;
        Board<char>* board_pointer = &wordBoard;

        Human_Player<char> player1(name2, 'S', board_pointer);
        Computer_Player<char> player2(name1, 'U', board_pointer);

        Player<char>* players[] = { &player2, &player1 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false, false, true, false, false, false, false);
    }

    else if (choice1 == "2" && choice2 == "2") {
        Word_Board<char> wordBoard;
        Board<char>* board_pointer = &wordBoard;

        Computer_Player<char> player1(name1, 'S', board_pointer);
        Computer_Player<char> player2(name2, 'U', board_pointer);

        Player<char>* players[] = { &player1, &player2 };

        vector<int> indexes = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

        Gaming<char> game(board_pointer, players, indexes);

        game.run_game(false, false, false, true, false, false, false, false);
    }
    else if (choice1 == "2" && choice2 == "3") {

    }
    else if (choice1 == "3" && choice2 == "1") {

    }
    else if (choice1 == "3" && choice2 == "2") {

    }
    else {

    }
}

void playNumericalTicTacToe(string &choice1, string &choice2, string &name1, string &name2) {
    if (choice1 == "1" && choice2 == "1") { // Human vs Human
        NumericalBoard<int> gameBoard;
        Board<int> *board_pointer = &gameBoard;

        Human_Player<int> player1(name1, 1, board_pointer); // Player 1 plays odd numbers
        Human_Player<int> player2(name2, 2, board_pointer); // Player 2 plays even numbers

        Player<int> *players[] = {&player1, &player2};

        vector<int> indexes = {0,1, 2, 3, 4, 5, 6, 7, 8};

        Gaming<int> game(board_pointer, players, indexes);

        game.run_game(false, false, false, false, true, false, false, false);
    } else if (choice1 == "1" && choice2 == "2") { // Human vs Computer
        NumericalBoard<int> gameBoard;
        Board<int> *board_pointer = &gameBoard;

        Human_Player<int> player1(name1, 1, board_pointer);
        Computer_Player<int> player2(name2, 2, board_pointer);

        Player<int> *players[] = {&player1, &player2};

        vector<int> indexes = {0,1, 2, 3, 4, 5, 6, 7, 8};

        Gaming<int> game(board_pointer, players, indexes);

        game.run_game(false, false, false, false, true, false, false, false);
    } else if (choice1 == "2" && choice2 == "1") { // Computer vs Human
        NumericalBoard<int> gameBoard;
        Board<int> *board_pointer = &gameBoard;

        Computer_Player<int> player1(name1, 1, board_pointer);
        Human_Player<int> player2(name2, 2, board_pointer);

        Player<int> *players[] = {&player1, &player2};

        vector<int> indexes = {0,1, 2, 3, 4, 5, 6, 7, 8};

        Gaming<int> game(board_pointer, players, indexes);

        game.run_game(false, false, false, false, true, false, false, false);
    } else if (choice1 == "2" && choice2 == "2") { // Computer vs Computer
        NumericalBoard<int> gameBoard;
        Board<int> *board_pointer = &gameBoard;

        Computer_Player<int> player1(name1, 1, board_pointer);
        Computer_Player<int> player2(name2, 2, board_pointer);

        Player<int> *players[] = {&player1, &player2};

        vector<int> indexes = {0,1, 2, 3, 4, 5, 6, 7, 8};

        Gaming<int> game(board_pointer, players, indexes);

        game.run_game(false, false, false, false, true, false, false, false);
    }


}
void manager() {
    string choice = menu();
    if (choice == "9") {
        cout << "Thanks for using our application" << endl;
        exit(0);
    }

    cout << "Choose Player 1 name" << endl;
    string name1;
    cin >> name1;
    cout << "Choose type of player 1" << endl;
    string sub_choice_1 = sub_menu();

    cout << "Choose Player 2 name" << endl;
    string name2;
    cin >> name2;
    cout << "Choose type of player 2" << endl;
    string sub_choice_2 = sub_menu();

    switch (stoi(choice)) {
        case 1:
            pyramic(sub_choice_1, sub_choice_2, name1, name2);
            break;
        case 2:
            playFourInARow(sub_choice_1, sub_choice_2, name1, name2);
            break;
        case 3:
            five_by_five(sub_choice_1, sub_choice_2, name1, name2);
            break;
        case 4:
            word_tic_tac_toe(sub_choice_1, sub_choice_2, name1, name2);
            break;
        case 5:
            playNumericalTicTacToe(sub_choice_1, sub_choice_2, name1, name2);
            break;
        case 6:
            misere_tic_tac_toe(sub_choice_1, sub_choice_2, name1, name2);
            break;
        case 8:
            sus_game(sub_choice_1, sub_choice_2, name1, name2);
            break;
        default:
            break;
    }
    manager();
}

int main() {
    manager();
}