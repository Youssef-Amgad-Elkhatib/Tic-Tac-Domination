#ifndef BOARD_GAMES_HUMAN_PLAYER_H
#define BOARD_GAMES_HUMAN_PLAYER_H
#include "BoardGame_Classes.h"
#include "Games.h"

template <class T>
struct SharedData {
    vector<int> fivebyfive = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };
    vector<int> indexes = {0, 1, 2, 3, 4, 5, 6, 7, 8 };
    vector<int> connectindexes = { 0, 1, 2, 3, 4, 5, 6 };
    vector<char> alphabet{'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    vector<char> odd_numbers{'1','3','5','7','9'};
    vector<char> even_numbers{'2','4','6','8'};
    vector<int> available={0,1,2,3,4,5,6,7,8};
    vector<int> Ultimateindexes{
            0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
            20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37,
            38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55,
            56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73,
            74, 75, 76, 77, 78, 79, 80
    };
};

template<class T>
class Human_Player : public Player<T> {
private:
    bool check = true;
    bool number = false;
    bool word = false;
    bool five=false;
    bool connect = false;
    bool Ultimate=false;
    bool special=false;
    int turn = 1;

    shared_ptr<SharedData<T>> sharedData;

    void check_board() {
        if (check) {
            // Check for NumericalBoard
            if (auto numericalBoard = dynamic_cast<NumericalBoard<T> *>(this->boardPtr)) {
                number = true;
            }
                // Check for Word_Board
            else if (auto wordBoard = dynamic_cast<Word_Board<T> *>(this->boardPtr)) {
                word = true;
            }
                // Check for FourInARow
            else if (auto fourInARowBoard = dynamic_cast<FourInARow<T> *>(this->boardPtr)) {
                connect = true;
            }
                // Check for FiveByFiveBoard
            else if (auto fiveByFiveBoard = dynamic_cast<FiveByFiveBoard<T> *>(this->boardPtr)) {
                five=true;
            }
            else if(auto ultimate=dynamic_cast<UltimateTicTacToe<T> *>(this->boardPtr)){
                Ultimate= true;
            }

            check = false; // Mark check as complete
        }
    }

    bool validate_index(const std::string& x) {
        for (auto i : x) {
            if (!isdigit(i)) return false;
        }
        return true;
    }

    char validate_input(std::string x, std::vector<char>& v) {
        while (true) {
            if (x.length() != 1) {
                std::cout << "Please enter a valid input" << std::endl;
                std::cin >> x;
            }
            else break;
        }

        auto it = std::find(v.begin(), v.end(), std::tolower(x[0]));
        while (true) {
            if (x.length() != 1 || it == v.end()) {
                std::cout << "Please enter a valid input" << std::endl;
                std::cin >> x;
                it = std::find(v.begin(), v.end(), std::tolower(x[0]));
            }
            else break;
        }

        if (number) {
            v.erase(it);
            return toupper(x[0]);
        }
        else return toupper(x[0]);
    }

    void setsymbol() {
        cout << "Please enter character/number you want to play" << endl;
        string x;
        cin >> x;
        char c;
        if (number && turn == 1)
            c = validate_input(x, sharedData->odd_numbers);
        else if (word)
            c = validate_input(x, sharedData->alphabet);
        else if (number && turn == 2) {
            c = validate_input(x, sharedData->even_numbers);
        }
        this->symbol = c;
    }

    void make_move() {
        if (number || word) setsymbol();

        int chosenIndex = -1;
        string index;

        cout << this->getname() << ", please enter an index:" << std::endl;

        while (true) {
            cin >> index;

            if (!validate_index(index)) {
                std::cout << "Invalid input. Please enter a valid index:" << std::endl;
                continue;
            }

            try {
                chosenIndex = std::stoi(index);
            } catch (const invalid_argument& e) {
                cout << "Invalid index format. Please enter a valid integer index:" << std::endl;
                continue;
            }
            if(!connect && !five && !Ultimate) {
                auto it = find(sharedData->indexes.begin(), sharedData->indexes.end(), chosenIndex);
                if (it == sharedData->indexes.end()) {
                    cout << "Index already chosen or out of range. Please enter a valid index:" << std::endl;
                    continue;
                }
                else sharedData->indexes.erase(it);
            }
            else if(connect){
                auto it = find(sharedData->connectindexes.begin(), sharedData->connectindexes.end(), chosenIndex);
                if (it == sharedData->connectindexes.end()) {
                    cout << "Index already chosen or out of range. Please enter a valid index:" << std::endl;
                    continue;
                }
            }
            else if(Ultimate){
                auto it = find(sharedData->Ultimateindexes.begin(), sharedData->Ultimateindexes.end(), chosenIndex);
                if (it == sharedData->Ultimateindexes.end()) {
                    cout << "Index already chosen or out of range. Please enter a valid index:" << std::endl;
                    continue;
                }
                else sharedData->Ultimateindexes.erase(it);
            }
            else if(five){
                auto it = find(sharedData->fivebyfive.begin(), sharedData->fivebyfive.end(), chosenIndex);
                if (it == sharedData->fivebyfive.end()) {
                    cout << "Index already chosen or out of range. Please enter a valid index:" << std::endl;
                    continue;
                }
                else sharedData->fivebyfive.erase(it);
            }
            if (connect) {
                FourInARow<char>* ptr2 = dynamic_cast<FourInARow<T>*>(this->boardPtr);
                if (ptr2 && ptr2->check(chosenIndex, chosenIndex)) {
                    std::cout << "Please choose a different index:" << std::endl;
                    continue;
                }
            }
            break;
        }
        this->boardPtr->update_board(chosenIndex, chosenIndex, this->getsymbol());
    }

public:
    Human_Player(string x, T sym, Board<T>* c, shared_ptr<SharedData<T>> data)
            : Player<T>(x, sym), sharedData(data) {
        this->setBoard(c);
    }

    void getmove(int& x, int& y) {
        if (auto misere = dynamic_cast<MisereTicTacToe<T> *>(this->boardPtr)){
            if(misere->get_win())return;
        }
        if (auto fivebyfive = dynamic_cast<FiveByFiveBoard<T> *>(this->boardPtr)){
            if(fivebyfive->get_win())return;
        }
        if (auto sus = dynamic_cast<SUS<T> *>(this->boardPtr)){
            if(sus->get_win())return;
        }
        check_board();
        make_move();
    }

    void set_turn(int number) {
        turn = number;
    }
};

template <class T>
class Computer_Player : public Player<T> {
private:
    bool check = true;
    bool number = false;
    bool word = false;
    bool connect = false;
    bool five=false;
    bool special=false;
    int turn=1;
    shared_ptr<SharedData<T>> sharedData;
    bool Ultimate=false;
    void check_board() {
        if (check) {
            // Check for NumericalBoard
            if (auto numericalBoard = dynamic_cast<NumericalBoard<T> *>(this->boardPtr)) {
                number = true;
            }
                // Check for Word_Board
            else if (auto wordBoard = dynamic_cast<Word_Board<T> *>(this->boardPtr)) {
                word = true;
            }
                // Check for FourInARow
            else if (auto fourInARowBoard = dynamic_cast<FourInARow<T> *>(this->boardPtr)) {
                connect = true;
            }
                // Check for FiveByFiveBoard
            else if (auto fiveByFiveBoard = dynamic_cast<FiveByFiveBoard<T> *>(this->boardPtr)) {
                five= true;
            }
            else if(auto ultimate = dynamic_cast<UltimateTicTacToe<T> *>(this->boardPtr)){
                Ultimate=true;
            }
            check = false; // Mark check as complete
        }
    }

    void setsymbol() {
        char x;
        // For the computer player, symbol is chosen randomly
        if (number && turn == 1) {
            x = (sharedData->odd_numbers[rand() % sharedData->odd_numbers.size()]);
            cout<<this->getname()<<" chooses "<<x<<endl;
            auto it=find(sharedData->odd_numbers.begin(),sharedData->odd_numbers.end(),x);
            sharedData->odd_numbers.erase(it);
        } else if (word) {
            x = sharedData->alphabet[rand() % sharedData->alphabet.size()];
            cout<<this->getname()<<" chooses "<<x<<endl;
        } else if (number && turn == 2) {
            x = (sharedData->even_numbers[rand() % sharedData->even_numbers.size()]);
            cout<<this->getname()<<" chooses "<<x<<endl;
            auto it=find(sharedData->even_numbers.begin(),sharedData->even_numbers.end(),x);
            sharedData->even_numbers.erase(it);
        }
        this->symbol = toupper(x);
    }

    void make_move() {
        if (number || word) setsymbol();
        int randomIndex,chosenIndex;
        // Randomly pick an index from available valid indexes
        random_device rd;
        mt19937 gen(rd());
        if(!connect && !five && !Ultimate) {
            uniform_int_distribution<> dist(0, sharedData->indexes.size() - 1);

            randomIndex = dist(gen);
            chosenIndex = sharedData->indexes[randomIndex];

            cout << this->getname() << " chooses index: " << chosenIndex << std::endl;

            // Remove the chosen index from available indexes
            sharedData->indexes.erase(sharedData->indexes.begin() + randomIndex);
            this->boardPtr->update_board(chosenIndex, chosenIndex, this->getsymbol());
        }

        if(five){
            uniform_int_distribution<> dist(0, sharedData->fivebyfive.size() - 1);

            randomIndex = dist(gen);
            chosenIndex = sharedData->fivebyfive[randomIndex];

            cout << this->getname() << " chooses index: " << chosenIndex << std::endl;

            // Remove the chosen index from available indexes
            sharedData->fivebyfive.erase(sharedData->fivebyfive.begin() + randomIndex);
            this->boardPtr->update_board(chosenIndex, chosenIndex, this->getsymbol());
        }
        else if(Ultimate){
            uniform_int_distribution<> dist(0, sharedData->Ultimateindexes.size() - 1);

            randomIndex = dist(gen);
            chosenIndex = sharedData->Ultimateindexes[randomIndex];

            cout << this->getname() << " chooses index: " << chosenIndex << std::endl;

            // Remove the chosen index from available indexes
            sharedData->Ultimateindexes.erase(sharedData->Ultimateindexes.begin() + randomIndex);
            this->boardPtr->update_board(chosenIndex, chosenIndex, this->getsymbol());
        }
        else if(connect){
            uniform_int_distribution<> dist(0, sharedData->connectindexes.size() - 1);

            randomIndex = dist(gen);
            chosenIndex = sharedData->connectindexes[randomIndex];

            cout << this->getname() << " chooses index: " << chosenIndex << std::endl;

            this->boardPtr->update_board(chosenIndex, chosenIndex, this->getsymbol());
        }
    }

public:
    Computer_Player(std::string x, T sym, Board<T>* c, std::shared_ptr<SharedData<T>> data)
            : Player<T>(x, sym), sharedData(data) {
        this->setBoard(c);
    }

    void getmove(int& x, int& y) {
        if (auto misere = dynamic_cast<MisereTicTacToe<T> *>(this->boardPtr)){
            if(misere->get_win())return;
        }
        if (auto fivebyfive = dynamic_cast<FiveByFiveBoard<T> *>(this->boardPtr)){
            if(fivebyfive->get_win())return;
        }
        if (auto sus = dynamic_cast<SUS<T> *>(this->boardPtr)){
            if(sus->get_win())return;
        }
        check_board();
        make_move();
    }

    void set_turn(int number) {
        turn = number;
    }
    void checkplayers(Player<char>* players[]){
        if(players[0]==players[1])special=false;
        else{
            special= true;
        }
    }
};

template <class T>
class Pyramic_AI:public Player<T>{
    shared_ptr<SharedData<T>> sharedData;
    Player<T>* gaming_players[2];
    int minimax(Board<T>* board, bool isMaximizing, T aiSymbol, T opponentSymbol, int alpha, int beta, const vector<int>& indexes) {
        // Base case: Check terminal state
        if (board->is_win()) {
            return isMaximizing ? -1 : 1; // AI loses if opponent wins, and vice versa
        }
        if (board->is_draw() || indexes.empty()) {
            return 0; // Draw
        }

        // Recursive case
        if (isMaximizing) {
            int bestScore = INT_MIN;

            // Iterate through all possible moves
            for (int index : indexes) {
                // Simulate the move
                board->update_board(index, index, aiSymbol);

                // Create updated indexes for recursion
                vector<int> updatedIndexes = indexes;
                updatedIndexes.erase(find(updatedIndexes.begin(), updatedIndexes.end(), index));

                // Evaluate recursively
                int score = minimax(board, false, aiSymbol, opponentSymbol, alpha, beta, updatedIndexes);

                // Undo the move
                board->update_board(index, index, '-');

                bestScore = max(bestScore, score);
                alpha = max(alpha, bestScore);

                // Prune unnecessary branches
                if (beta <= alpha) {
                    break;
                }
            }
            return bestScore;
        } else {
            int bestScore = INT_MAX;

            // Iterate through all possible moves
            for (int index : indexes) {
                // Simulate the move
                board->update_board(index, index, opponentSymbol);

                // Create updated indexes for recursion
                vector<int> updatedIndexes = indexes;
                updatedIndexes.erase(find(updatedIndexes.begin(), updatedIndexes.end(), index));

                // Evaluate recursively
                int score = minimax(board, true, aiSymbol, opponentSymbol, alpha, beta, updatedIndexes);

                // Undo the move
                board->update_board(index, index, '-');

                bestScore = min(bestScore, score);
                beta = min(beta, bestScore);

                // Prune unnecessary branches
                if (beta <= alpha) {
                    break;
                }
            }
            return bestScore;
        }
    }
    void make_move() {
        int bestMove = -1;

        // Determine the AI's index and the opponent's index dynamically
        int aiIndex = (gaming_players[0] == this) ? 0 : 1;
        int opponentIndex = 1 - aiIndex; // The other player is the opponent

        T aiSymbol = this->getsymbol();
        T opponentSymbol = gaming_players[opponentIndex]->getsymbol();

        // Step 1: Try to win in the current turn
        for (int index : sharedData->indexes) {
            this->boardPtr->update_board(index, index, aiSymbol);
            if (this->boardPtr->is_win()) {
                bestMove = index;
            }
            this->boardPtr->update_board(index, index, '-'); // Undo move
            if (bestMove != -1) break;
        }

        // Step 2: Try to block the opponent from winning
        if (bestMove == -1) {
            for (int index : sharedData->indexes) {
                this->boardPtr->update_board(index, index, opponentSymbol);
                if (this->boardPtr->is_win()) {
                    bestMove = index;
                }
                this->boardPtr->update_board(index, index, '-'); // Undo move
                if (bestMove != -1) break;
            }
        }

        // Step 3: Use minimax to find the best move for the future
        if (bestMove == -1) {
            int bestScore = INT_MIN;

            for (int index : sharedData->indexes) {
                // Simulate the move
                this->boardPtr->update_board(index, index, aiSymbol);

                // Create updated indexes for recursion
                vector<int> updatedIndexes = sharedData->indexes;
                updatedIndexes.erase(find(updatedIndexes.begin(), updatedIndexes.end(), index));

                // Recursively evaluate the move using minimax
                int moveScore = minimax(this->boardPtr, false, aiSymbol, opponentSymbol, INT_MIN, INT_MAX, updatedIndexes);

                // Undo the move
                this->boardPtr->update_board(index, index, '-');

                // Update the best move
                if (moveScore > bestScore) {
                    bestScore = moveScore;
                    bestMove = index;
                }
            }
        }

        // Perform the chosen move
        if (bestMove != -1) {
            cout << this->getname() << " chooses " << bestMove << endl;
            this->boardPtr->update_board(bestMove, bestMove, aiSymbol);
            sharedData->indexes.erase(remove(sharedData->indexes.begin(), sharedData->indexes.end(), bestMove), sharedData->indexes.end());
        }
    }


public:
    Pyramic_AI(string x, T sym, Board<T>* c, shared_ptr<SharedData<T>> data)
            : Player<T>(x, sym), sharedData(data) {
        this->setBoard(c);

    }
    void getmove(int&x, int&y){
        make_move();
    }
    void get_players(Player<T>* players[2]){
        gaming_players[0]=players[0];
        gaming_players[1]=players[1];
    }


};

template <class T>
class Word_AI : public Player<T> {
    shared_ptr<SharedData<T>> sharedData;
    Player<T>* gaming_players[2];
    vector<string> dictionary;

    // Load the dictionary from a file
    void load_dictionary(const string& filename) {
        ifstream file(filename);
        string word;
        while (file >> word) {
            dictionary.push_back(word);
        }
        file.close();
    }

    // Check if a word is valid
    bool is_valid_word(const string& word) {
        return find(dictionary.begin(), dictionary.end(), word) != dictionary.end() || find(dictionary.begin(), dictionary.end(),
                                                                                            reverser(word))!=dictionary.end();
    }
    string reverser(string  word){
        reverse(word.begin(),word.end());
        return word;
    }
    // Check if placing a symbol at a position can form a winning word
    bool is_winning_move(Board<T>* board, int position, T symbol) {
        // Temporarily place the symbol
        board->update_board(position, position, symbol);

        // Check for valid words in rows, columns, and diagonals
        bool isWinning = check_specific_combinations();

        // Undo the move
        board->update_board(position, position, '-');

        return isWinning;
    }

    // Check specific row, column, and diagonal combinations for a valid word
    bool check_specific_combinations() {
        auto board = dynamic_cast<Word_Board<T> *>(this->boardPtr);
        string row1 = string(1, board->get_value(0)) + board->get_value(1) + board->get_value(2); // Row 1
        string row2 = string(1, board->get_value(3)) + board->get_value(4) + board->get_value(5); // Row 2
        string row3 = string(1, board->get_value(6)) + board->get_value(7) + board->get_value(8); // Row 3

        string col1 = string(1, board->get_value(0)) + board->get_value(3) + board->get_value(6); // Column 1
        string col2 = string(1, board->get_value(1)) + board->get_value(4) + board->get_value(7); // Column 2
        string col3 = string(1, board->get_value(2)) + board->get_value(5) + board->get_value(8); // Column 3

        string diag1 = string(1, board->get_value(0)) + board->get_value(4) + board->get_value(8); // Diagonal 1
        string diag2 = string(1, board->get_value(2)) + board->get_value(4) + board->get_value(6); // Diagonal 2

        // Check each combination against the dictionary
        return is_valid_word(row1) || is_valid_word(row2) || is_valid_word(row3) ||
               is_valid_word(col1) || is_valid_word(col2) || is_valid_word(col3) ||
               is_valid_word(diag1) || is_valid_word(diag2);
    }

    // Perform the AI move
    void make_move() {
        int bestMove = -1;
        T aiSymbol;
        for(int i: sharedData->alphabet) {
            aiSymbol= toupper(i);
            // Step 1: Try to win on this turn
            for (int position: sharedData->indexes) {
                if (is_winning_move(this->boardPtr, position, aiSymbol)) {
                    bestMove = position;
                    break;
                }
            }
            if(bestMove!=-1)break;
        }
        // step 2 choose prioritized alphabet and index
        if (bestMove == -1 && !sharedData->indexes.empty()) {
            // Define priority order for positions: corners > edges > center
            // Try to pick the first available position in the prioritized order
            vector<char> letters = {'A', 'E', 'I'};
            // Initialize random number generator
            random_device rd;  // Obtain a random number from hardware
            mt19937 gen(rd()); // Seed the generator
            uniform_int_distribution<> dist(0, 2);
            aiSymbol=letters[dist(gen)];
            vector<int> priorityOrder;
            if(aiSymbol=='A')priorityOrder={0,2,6,8,4,1,3,5,7};
            else priorityOrder={4,1,3,5,7,0,2,6,8};
            for (int pos : priorityOrder) {
                if (find(sharedData->indexes.begin(), sharedData->indexes.end(), pos) != sharedData->indexes.end()) {
                    // If the position is available, make the move
                    bestMove = pos;
                    break;
                }
            }

        }




        // Perform the move
        if (bestMove != -1) {
            cout << this->getname() << " chooses position " << bestMove << endl;
            cout<<this->getname() << " chooses character " << aiSymbol << endl;
            this->boardPtr->update_board(bestMove, bestMove, aiSymbol);
            sharedData->indexes.erase(remove(sharedData->indexes.begin(), sharedData->indexes.end(), bestMove), sharedData->indexes.end());
        }
    }

public:
    Word_AI(string x, T sym, Board<T>* c, shared_ptr<SharedData<T>> data)
            : Player<T>(x, sym), sharedData(data) {
        this->setBoard(c);
        load_dictionary("dic.txt");
    }

    void getmove(int& x, int& y) {
        make_move();
    }

    void get_players(Player<T>* players[2]) {
        gaming_players[0] = players[0];
        gaming_players[1] = players[1];
    }
};

template <class T>
class NumericalBoardAI : public Player<T> {
    shared_ptr<SharedData<T>> sharedData;
    Player<T>* gaming_players[2];

    int minimax(Board<T>* board, bool isMaximizing, T aiSymbol, T opponentSymbol, int alpha, int beta, const vector<int>& indexes) {
        // Base case: Check terminal state
        if (board->is_win()) {
            return isMaximizing ? -1 : 1; // AI loses if opponent wins, and vice versa
        }
        if (board->is_draw() || indexes.empty()) {
            return 0; // Draw
        }

        // Recursive case
        if (isMaximizing) {
            int bestScore = INT_MIN;

            // Iterate through all possible moves
            for (int index : indexes) {
                // Simulate the move
                board->update_board(index, index, aiSymbol);

                // Create updated indexes for recursion
                vector<int> updatedIndexes = indexes;
                updatedIndexes.erase(find(updatedIndexes.begin(), updatedIndexes.end(), index));

                // Evaluate recursively
                int score = minimax(board, false, aiSymbol, opponentSymbol, alpha, beta, updatedIndexes);

                // Undo the move
                board->update_board(index, index, '-');

                bestScore = max(bestScore, score);
                alpha = max(alpha, bestScore);

                // Prune unnecessary branches
                if (beta <= alpha) {
                    break;
                }
            }
            return bestScore;
        } else {
            int bestScore = INT_MAX;

            // Iterate through all possible moves
            for (int index : indexes) {
                // Simulate the move
                board->update_board(index, index, opponentSymbol);

                // Create updated indexes for recursion
                vector<int> updatedIndexes = indexes;
                updatedIndexes.erase(find(updatedIndexes.begin(), updatedIndexes.end(), index));

                // Evaluate recursively
                int score = minimax(board, true, aiSymbol, opponentSymbol, alpha, beta, updatedIndexes);

                // Undo the move
                board->update_board(index, index, '-');

                bestScore = min(bestScore, score);
                beta = min(beta, bestScore);

                // Prune unnecessary branches
                if (beta <= alpha) {
                    break;
                }
            }
            return bestScore;
        }
    }
    void make_move() {
        int bestMove = -1;
        char chosenNumber = '-';

        // Determine the AI's index and the opponent's index dynamically
        int aiIndex = (gaming_players[0] == this) ? 0 : 1;
        int opponentIndex = 1 - aiIndex;

        T aiSymbol = this->getsymbol();
        T opponentSymbol = gaming_players[opponentIndex]->getsymbol();

        // Dynamically select which numbers (odd or even) the AI uses
        vector<char>& aiNumbers = (aiIndex == 0) ? sharedData->odd_numbers : sharedData->even_numbers;
        vector<char>& opponentNumbers = (aiIndex == 0) ? sharedData->even_numbers : sharedData->odd_numbers;

        // Iterate over all available indexes
        for (int index : sharedData->indexes) {
            // Loop through AI's set of numbers
            for (char number : aiNumbers) {
                // Simulate the AI's move
                this->boardPtr->update_board(index, index, number);

                // Check if this move directly wins the game
                if (this->boardPtr->is_win()) {
                    bestMove = index;
                    chosenNumber = number;
                    this->boardPtr->update_board(index, index, '-'); // Undo move
                    goto finalize_move; // Jump to finalize and execute the move
                }
                this->boardPtr->update_board(index, index, '-'); // Undo move
            }

            // Loop through the opponent's set of numbers (for blocking)
            for (char number : opponentNumbers) {
                // Simulate the opponent's move to check if they would win
                this->boardPtr->update_board(index, index, number);

                if (this->boardPtr->is_win()) {
                    // Block the opponent's winning move
                    bestMove = index;
                    chosenNumber = aiNumbers[rand() % aiNumbers.size()]; // Random valid AI number
                    this->boardPtr->update_board(index, index, '-'); // Undo move
                    goto finalize_move;
                }
                this->boardPtr->update_board(index, index, '-'); // Undo move
            }
        }

        // If no winning/blocking move found, pick the first available move and number
        if (bestMove == -1) {
            // Randomly choose an index from the available indexes
            int randomIndex = rand() % sharedData->indexes.size();
            bestMove = sharedData->indexes[randomIndex];

            // Randomly choose a number from the AI's numbers (odd or even)
            int randomNumberIndex = rand() % aiNumbers.size();
            chosenNumber = aiNumbers[randomNumberIndex];
        }


    finalize_move:
        // Execute the chosen move
        if (bestMove != -1 && chosenNumber != '-') {
            cout << this->getname() << " chooses " << chosenNumber << " and index " << bestMove << endl;

            // Update the board
            this->boardPtr->update_board(bestMove, bestMove, chosenNumber);

            // Remove the index and number from sharedData
            sharedData->indexes.erase(remove(sharedData->indexes.begin(), sharedData->indexes.end(), bestMove), sharedData->indexes.end());
            sharedData->odd_numbers.erase(remove(sharedData->odd_numbers.begin(), sharedData->odd_numbers.end(), chosenNumber), sharedData->odd_numbers.end());
            sharedData->even_numbers.erase(remove(sharedData->even_numbers.begin(), sharedData->even_numbers.end(), chosenNumber), sharedData->even_numbers.end());
        }
    }


public:
    NumericalBoardAI(string x, T sym, Board<T>* c, shared_ptr<SharedData<T>> data)
            : Player<T>(x, sym), sharedData(data) {
        this->setBoard(c);
    }

    void getmove(int& x, int& y) {
        make_move();
    }

    void get_players(Player<T>* players[2]) {
        gaming_players[0] = players[0];
        gaming_players[1] = players[1];
    }
};
template <class T>
class FourInARowAI : public Player<T> {
    shared_ptr<SharedData<T>> sharedData;
    Player<T>* gaming_players[2];

    int minimax(Board<T>* board, bool isMaximizing, T aiSymbol, T opponentSymbol, int alpha, int beta, const vector<int>& indexes) {
        // Base case: Check terminal state
        if (board->is_win()) {
            return isMaximizing ? -1 : 1; // AI loses if opponent wins, and vice versa
        }
        if (board->is_draw() || indexes.empty()) {
            return 0; // Draw
        }
        auto Board = dynamic_cast<FourInARow<T>*>(board);
        // Recursive case
        if (isMaximizing) {
            int bestScore = INT_MIN;

            // Iterate through all possible moves
            for (int index : indexes) {
                // Simulate the move
                board->update_board(index, index, aiSymbol);

                // Create updated indexes for recursion
                vector<int> updatedIndexes = indexes;
                updatedIndexes.erase(find(updatedIndexes.begin(), updatedIndexes.end(), index));

                // Evaluate recursively
                int score = minimax(board, false, aiSymbol, opponentSymbol, alpha, beta, updatedIndexes);

                // Undo the move
                Board->update_AI(index, index, aiSymbol);

                bestScore = max(bestScore, score);
                alpha = max(alpha, bestScore);

                // Prune unnecessary branches
                if (beta <= alpha) {
                    break;
                }
            }
            return bestScore;
        } else {
            int bestScore = INT_MAX;

            // Iterate through all possible moves
            for (int index : indexes) {
                // Simulate the move
                board->update_board(index, index, opponentSymbol);

                // Create updated indexes for recursion
                vector<int> updatedIndexes = indexes;
                updatedIndexes.erase(find(updatedIndexes.begin(), updatedIndexes.end(), index));

                // Evaluate recursively
                int score = minimax(board, true, aiSymbol, opponentSymbol, alpha, beta, updatedIndexes);

                // Undo the move
                Board->update_AI(index, index, opponentSymbol);

                bestScore = min(bestScore, score);
                beta = min(beta, bestScore);

                // Prune unnecessary branches
                if (beta <= alpha) {
                    break;
                }
            }
            return bestScore;
        }
    }

    void make_move() {
        int bestMove = -1;
        int aiIndex = (gaming_players[0] == this) ? 0 : 1;
        int opponentIndex = 1 - aiIndex;

        T aiSymbol = this->getsymbol();
        T opponentSymbol = gaming_players[opponentIndex]->getsymbol();

        auto board = dynamic_cast<FourInARow<T>*>(this->boardPtr);

        for (int index : sharedData->connectindexes) {
            this->boardPtr->update_board(index, index, aiSymbol);
            if (this->boardPtr->is_win()) {
                bestMove = index;
            }
            board->update_AI(index, index, aiSymbol);

            this->boardPtr->update_board(index, index, opponentSymbol);
            if (this->boardPtr->is_win()) {
                bestMove = index;
            }
            board->update_AI(index, index, opponentSymbol);

            if (bestMove != -1) break;
        }


        if (bestMove == -1) {
            int bestScore = INT_MIN;

            for (int index : sharedData->connectindexes) {
                this->boardPtr->update_board(index, index, aiSymbol);

                vector<int> updatedIndexes = sharedData->connectindexes;
                updatedIndexes.erase(find(updatedIndexes.begin(), updatedIndexes.end(), index));

                int moveScore = minimax(this->boardPtr, false, aiSymbol, opponentSymbol, INT_MIN, INT_MAX, updatedIndexes);

                board->update_AI(index, index, aiSymbol);

                if (moveScore > bestScore) {
                    bestScore = moveScore;
                    bestMove = index;
                }
            }
        }


        if (bestMove != -1) {
            cout << this->getname() << " chooses " << bestMove << endl;
            this->boardPtr->update_board(bestMove, bestMove, aiSymbol);

            if (board->check(bestMove, 0)) {
                sharedData->connectindexes.erase(
                        remove(sharedData->connectindexes.begin(), sharedData->connectindexes.end(), bestMove),
                        sharedData->connectindexes.end()
                );
            }
        }
    }

public:
    FourInARowAI(string x, T sym, Board<T>* c, shared_ptr<SharedData<T>> data)
            : Player<T>(x, sym), sharedData(data) {
        this->setBoard(c);
    }

    void getmove(int& x, int& y) {
        make_move();
    }

    void get_players(Player<T>* players[2]) {
        gaming_players[0] = players[0];
        gaming_players[1] = players[1];
    }
};

template <class T>
class FivebyFive_AI:public Player<T>{
    shared_ptr<SharedData<T>> sharedData;
    Player<T>* gaming_players[2];

    void make_move() {
        int bestMove = -1;

        // Determine the AI's index and the opponent's index dynamically
        int aiIndex = (gaming_players[0] == this) ? 0 : 1;
        int opponentIndex = 1 - aiIndex; // The other player is the opponent

        T aiSymbol = this->getsymbol();
        T opponentSymbol = gaming_players[opponentIndex]->getsymbol();
        auto board = dynamic_cast<FiveByFiveBoard<T> *>(this->boardPtr);
        // Step 1: Try to win in the current turn
        for (int index : sharedData->fivebyfive) {
            this->boardPtr->update_board(index, index, aiSymbol);
            if (board->AI_win(index)) {
                bestMove = index;
            }
            this->boardPtr->update_board(index, index, '-'); // Undo move
            if (bestMove != -1) break;
        }

        // Step 2: Try to block the opponent from winning
        if (bestMove == -1) {
            for (int index : sharedData->fivebyfive) {
                this->boardPtr->update_board(index, index, opponentSymbol);
                if (board->AI_win(index)) {
                    bestMove = index;
                }
                this->boardPtr->update_board(index, index, '-'); // Undo move
                if (bestMove != -1) break;
            }
        }


        if (bestMove == -1) {
            bestMove=board->AI_move(aiSymbol);
        }
        if(bestMove==-1){
            random_device rd;
            mt19937 gen(rd());
            uniform_int_distribution<> dist(0, sharedData->fivebyfive.size() - 1);

            int randomIndex = dist(gen);
            bestMove = sharedData->fivebyfive[randomIndex];
        }

        // Perform the chosen move
        if (bestMove != -1) {
            cout << this->getname() << " chooses " << bestMove << endl;
            this->boardPtr->update_board(bestMove, bestMove, aiSymbol);
            sharedData->fivebyfive.erase(remove(sharedData->fivebyfive.begin(), sharedData->fivebyfive.end(), bestMove), sharedData->fivebyfive.end());
        }
    }


public:
    FivebyFive_AI(string x, T sym, Board<T>* c, shared_ptr<SharedData<T>> data)
            : Player<T>(x, sym), sharedData(data) {
        this->setBoard(c);

    }
    void getmove(int&x, int&y){
        if (auto fivebyfive = dynamic_cast<FiveByFiveBoard<T> *>(this->boardPtr)){
            if(fivebyfive->get_win())return;
        }
        make_move();
    }
    void get_players(Player<T>* players[2]){
        gaming_players[0]=players[0];
        gaming_players[1]=players[1];
    }


};

template <class T>
class Misere_AI:public Player<T>{
    shared_ptr<SharedData<T>> sharedData;
    Player<T>* gaming_players[2];

    void make_move() {
        int bestMove = -1;

        // Determine the AI's index and the opponent's index dynamically
        int aiIndex = (gaming_players[0] == this) ? 0 : 1;
        int opponentIndex = 1 - aiIndex; // The other player is the opponent

        T aiSymbol = this->getsymbol();
        T opponentSymbol = gaming_players[opponentIndex]->getsymbol();
        auto board = dynamic_cast<MisereTicTacToe<T> *>(this->boardPtr);
        // Step 1: Try to win in the current turn
        for (int index : sharedData->indexes) {
            this->boardPtr->update_board(index, index, aiSymbol);
            if (!board->AI_lose()) {
                this->boardPtr->update_board(index, index, '-');
                this->boardPtr->update_board(index, index, opponentSymbol);
                if(!board->opponent_lose())bestMove=index;
            }
            this->boardPtr->update_board(index, index, '-'); // Undo move
            if (bestMove != -1) break;
        }

        if (bestMove == -1) {
            for (int index : sharedData->indexes) {
                this->boardPtr->update_board(index, index, aiSymbol);
                if (!board->AI_lose()) {
                    bestMove=index;
                }
                this->boardPtr->update_board(index, index, '-'); // Undo move
                if (bestMove != -1) break;
            }
        }

        if(bestMove==-1){
            random_device rd;
            mt19937 gen(rd());
            uniform_int_distribution<> dist(0, sharedData->indexes.size() - 1);
            int index=dist(gen);
            bestMove=sharedData->indexes[index];
        }

        // Perform the chosen move
        if (bestMove != -1) {
            cout << this->getname() << " chooses " << bestMove << endl;
            this->boardPtr->update_board(bestMove, bestMove, aiSymbol);
            sharedData->indexes.erase(remove(sharedData->indexes.begin(), sharedData->indexes.end(), bestMove), sharedData->indexes.end());
        }
    }


public:
    Misere_AI(string x, T sym, Board<T>* c, shared_ptr<SharedData<T>> data)
            : Player<T>(x, sym), sharedData(data) {
        this->setBoard(c);

    }
    void getmove(int&x, int&y){
        if (auto Misere = dynamic_cast<MisereTicTacToe<T> *>(this->boardPtr)){
            if(Misere->get_win())return;
        }
        make_move();
    }
    void get_players(Player<T>* players[2]){
        gaming_players[0]=players[0];
        gaming_players[1]=players[1];
    }


};




#endif //BOARD_GAMES_HUMAN_PLAYER_H