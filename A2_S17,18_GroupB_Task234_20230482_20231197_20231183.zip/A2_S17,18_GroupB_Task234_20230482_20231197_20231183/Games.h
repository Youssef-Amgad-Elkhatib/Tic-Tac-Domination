#include "BoardGame_Classes.h"
#ifndef BOARD_GAMES_PYRAMIC_H
#define BOARD_GAMES_PYRAMIC_H
#include <bits/stdc++.h>
using namespace std;
template<typename T>
class Pyramic_board : public Board<T> {
protected:
    vector<pair<int, char>> board; // Flattened board
    static const int levels = 3;

public:
    Pyramic_board() {
        board.clear();
        for (int i = 0; i <= 8; ++i) {
            board.emplace_back(i,'-');
        }
    }

    void display_board() {
        const int cell_width = 6; // Width of each cell
        const int total_width = levels * cell_width + (levels - 1) * cell_width; // Full width of the last level
        int currentIndex = 0;

        for (int i = 0; i < levels; ++i) {
            int numCells = 1 + (i * 2); // Calculate number of cells in the level

            // Calculate padding for alignment
            int padding = (total_width - (numCells * cell_width)) / 2;
            if (i == 1)cout << string(padding + 1, ' ');
            else if (i == 0)cout << string(padding + 2, ' ');
            else cout << string(padding, ' '); // Add left padding

            // Print each cell with separators
            for (int j = 0; j < numCells; ++j) {
                auto [index, symbol] = board[currentIndex++];
                cout << setw(cell_width) << left
                     << (" [" + to_string(index) + "] " + (symbol == ' ' ? "-" : string(1, symbol)));
                if (j < numCells - 1) cout << "|"; // Vertical separator
            }

            cout << "\n";
            if (i == 0) {
                cout << "             --------" << endl;
            } else if (i == 1) {
                cout<<"      -------+------+-------"<<endl;
            }

            else cout << "------+------+------+------+-----" << endl << endl;
        }
    }

    bool is_win() {
        // Hardcoded winning conditions for levels
        if (board[0].second == board[1].second && board[1].second == board[4].second && board[0].second != '-') return true;
        if (board[0].second == board[2].second && board[2].second == board[6].second && board[0].second != '-') return true;
        if (board[0].second == board[3].second && board[3].second == board[8].second && board[0].second != '-') return true;
        if (board[1].second == board[2].second && board[2].second == board[3].second && board[2].second != '-') return true;
        if (board[5].second == board[6].second && board[6].second == board[7].second && board[5].second != '-') return true;
        if (board[6].second == board[7].second && board[7].second == board[8].second && board[6].second != '-') return true;
        if (board[4].second == board[5].second && board[5].second == board[6].second && board[5].second != '-') return true;
        return false;
    }

    bool is_draw() {
        for(auto i:board){
            if(i.second=='-')return false;
        }
        return true;
    }

    bool game_is_over() {
        return is_win() || is_draw();
    }

    bool update_board(int x,int y,T symbol){
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }
        return true;
    }
};

//       game2 FourInRow       //
template <typename T>
class FourInARow : public Board<T> {
    std::vector<std::vector<std::pair<int, char>>> board;  // 2D vector for the board
    static const int rows = 6;     // Number of rows
    static const int columns = 7;  // Number of columns

public:
    FourInARow() {
        // Initialize the board with empty cells
        this->board.resize(rows, std::vector<std::pair<int, char>>(columns));

        // Fill each cell with a pair {column_index, '-'}
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < columns; ++j) {
                this->board[i][j] = {j, '-'}; // Each index initialized to '-' with its column index
            }
        }
        this->n_moves = 0;
    }

    bool update_board(int x, int y, T symbol) override {
        if(x<0 || x>6)return true;
        // Find the first empty spot in the column and place the symbol
        for (int i = rows - 1; i >= 0; --i) {
            if (board[i][x].second == '-') {  // Check if the cell is empty
                board[i][x].second = symbol;  // Place the symbol
                this->n_moves++;
                return true;
            }
        }
        return false; // Column is full
    }
    bool update_AI(int x, int y, T symbol) {
        if (x < 0 || x > 6) return false;
        for (int i = 0; i < rows; ++i) {
            if (board[i][x].second == symbol) {
                board[i][x].second = '-';
                //update_board(x , y ,'-');
                this->n_moves--;
                return true;
            }
        }
        return false;
    }
    void display_board() override {
        std::cout << "0 1 2 3 4 5 6" << std::endl;
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < columns; ++j) {
                std::cout << board[i][j].second << " ";
            }
            std::cout << std::endl;
        }
        std::cout << std::endl;
    }

    bool is_win() override {
        // Check rows, columns, and diagonals for 4-in-a-row
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < columns; ++j) {
                char current = board[i][j].second;
                if (current != '-') {
                    // Check horizontally
                    if (j + 3 < columns &&
                        current == board[i][j + 1].second &&
                        current == board[i][j + 2].second &&
                        current == board[i][j + 3].second) {
                        return true;
                    }
                    // Check vertically
                    if (i + 3 < rows &&
                        current == board[i + 1][j].second &&
                        current == board[i + 2][j].second &&
                        current == board[i + 3][j].second) {
                        return true;
                    }
                    // Check diagonally (bottom-left to top-right)
                    if (i + 3 < rows && j + 3 < columns &&
                        current == board[i + 1][j + 1].second &&
                        current == board[i + 2][j + 2].second &&
                        current == board[i + 3][j + 3].second) {
                        return true;
                    }
                    // Check diagonally (top-left to bottom-right)
                    if (i - 3 >= 0 && j + 3 < columns &&
                        current == board[i - 1][j + 1].second &&
                        current == board[i - 2][j + 2].second &&
                        current == board[i - 3][j + 3].second) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    bool is_draw() override {
        return this->n_moves == rows * columns && !is_win();
    }

    bool game_is_over() override {
        return is_win() || is_draw();
    }

    bool check(int x, int y) {
        // Check if the column is full
        return board[0][x].second != '-'; // Column is full if the top row is not empty
    }
};



template<typename T>
class FiveByFiveBoard : public Board<T> {
private:
    vector<pair<int, char>> board; // 1D vector to represent the 5x5 board
    static const int size = 5; // Size of the board (5x5)
    int player1ThreeInARow;
    int player2ThreeInARow;
    bool draw=false;
    bool win=false;
    bool checkThreeInARow(int index1, int index2, int index3) {
        return board[index1].second != '-' &&
               board[index1].second == board[index2].second &&
               board[index1].second == board[index3].second;
    }
public:
    // Constructor to initialize the board with pairs of (0, '-')
    FiveByFiveBoard() {
        board.clear();
        for (int i = 0; i <= 24; ++i) {
            board.emplace_back(i,'-');
        }
        player1ThreeInARow = 0;
        player2ThreeInARow = 0;
    }

    // Method to display the board
    void display_board() {
        if(win)return;
        const int cell_width = 6;
        const int separator_width = 1;
        int currentIndex = 0;

        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                auto [index, symbol] = board[currentIndex++];
                string index_str =  to_string(index);
                if(index>9)cout << setw(cell_width) << left
                                << ("[" + index_str + "] " + (symbol == '-' ? "-" : string(1, symbol)));
                else{
                    cout << setw(cell_width) << left
                         << ("[" + index_str + "]  " + (symbol == '-' ? "-" : string(1, symbol)));
                }
                if (j < size - 1) {
                    cout << "|";
                }
            }

            cout << "\n";

            if (i < size - 1) {
                cout << "------+------+------+------+------"<<endl;
            }
        }
        cout << "\n";
    }

// Method to check if there is a winner
    bool is_win() {
        if(win)return true;
        int notfilled=0;
        for (auto& cell : board) {
            if (cell.second == '-') {
                notfilled++;
            }
            if(notfilled>1)return false;
        }
        // Check horizontal rows for three consecutive symbols
        for (int row = 0; row < size; ++row) {
            for (int col = 0; col <= size - 3; ++col) {
                int index1 = row * size + col;
                int index2 = row * size + col + 1;
                int index3 = row * size + col + 2;
                if (board[index1].second != '-' &&
                    board[index1].second == board[index2].second &&
                    board[index1].second == board[index3].second) {
                    if (board[index1].second == 'X') player1ThreeInARow++;
                    else if (board[index1].second == 'O') player2ThreeInARow++;
                }
            }
        }

        // Check vertical columns for three consecutive symbols
        for (int col = 0; col < size; ++col) {
            for (int row = 0; row <= size - 3; ++row) {
                int index1 = row * size + col;
                int index2 = (row + 1) * size + col;
                int index3 = (row + 2) * size + col;
                if (board[index1].second != '-' &&
                    board[index1].second == board[index2].second &&
                    board[index1].second == board[index3].second) {
                    if (board[index1].second == 'X') player1ThreeInARow++;
                    else if (board[index1].second == 'O') player2ThreeInARow++;
                }
            }
        }

        // Check diagonal (top-left to bottom-right) for three consecutive symbols
        for (int row = 0; row <= size - 3; ++row) {
            for (int col = 0; col <= size - 3; ++col) {
                int index1 = row * size + col;
                int index2 = (row + 1) * size + (col + 1);
                int index3 = (row + 2) * size + (col + 2);
                if (board[index1].second != '-' &&
                    board[index1].second == board[index2].second &&
                    board[index1].second == board[index3].second) {
                    if (board[index1].second == 'X') player1ThreeInARow++;
                    else if (board[index1].second == 'O') player2ThreeInARow++;
                }
            }
        }

        // Check diagonal (top-right to bottom-left) for three consecutive symbols
        for (int row = 0; row <= size - 3; ++row) {
            for (int col = 2; col < size; ++col) {
                int index1 = row * size + col;
                int index2 = (row + 1) * size + (col - 1);
                int index3 = (row + 2) * size + (col - 2);
                if (board[index1].second != '-' &&
                    board[index1].second == board[index2].second &&
                    board[index1].second == board[index3].second) {
                    if (board[index1].second == 'X') player1ThreeInARow++;
                    else if (board[index1].second == 'O') player2ThreeInARow++;
                }
            }
        }
        cout<<player1ThreeInARow<<" "<<player2ThreeInARow<<endl;
        // Determine winner based on the number of three-in-a-row sequences
        if (player1ThreeInARow > player2ThreeInARow) {win=true;return false;} // Player 1 wins
        if (player2ThreeInARow > player1ThreeInARow) return true; // Player 2 wins
        else {
            draw= true;
            return false; // No winner yet
        }
    }
    bool get_win(){return win;}

    bool AI_win(int played_index) {
        int row = played_index / size;  // Calculate the row of the played index
        int col = played_index % size;  // Calculate the column of the played index

        // Check the row containing the played index
        for (int c = std::max(0, col - 2); c <= std::min(size - 3, col); ++c) {
            int index1 = row * size + c;
            int index2 = row * size + c + 1;
            int index3 = row * size + c + 2;
            if (checkThreeInARow(index1, index2, index3)) return true;
        }

        // Check the column containing the played index
        for (int r = std::max(0, row - 2); r <= std::min(size - 3, row); ++r) {
            int index1 = r * size + col;
            int index2 = (r + 1) * size + col;
            int index3 = (r + 2) * size + col;
            if (checkThreeInARow(index1, index2, index3)) return true;
        }

        // Check top-left to bottom-right diagonal
        for (int offset = -2; offset <= 0; ++offset) {
            if (row + offset >= 0 && row + offset + 2 < size &&
                col + offset >= 0 && col + offset + 2 < size) {
                int index1 = (row + offset) * size + (col + offset);
                int index2 = (row + offset + 1) * size + (col + offset + 1);
                int index3 = (row + offset + 2) * size + (col + offset + 2);
                if (checkThreeInARow(index1, index2, index3)) return true;
            }
        }

        // Check top-right to bottom-left diagonal
        for (int offset = -2; offset <= 0; ++offset) {
            if (row + offset >= 0 && row + offset + 2 < size &&
                col - offset >= 0 && col - offset - 2 < size) {
                int index1 = (row + offset) * size + (col - offset);
                int index2 = (row + offset + 1) * size + (col - offset - 1);
                int index3 = (row + offset + 2) * size + (col - offset - 2);
                if (checkThreeInARow(index1, index2, index3)) return true;
            }
        }
        return false;
    }
    // Method to check if the game is a draw (board is full)
    bool is_draw() {
        if(draw)return true;
        else return false;
    }
    int AI_move(T symbol){
        for(int i=0; i<=24; i++){
            if(board[i].second==symbol){
                if(i-6>=0 && board[i-6].second =='-')return i-6;
                if(i-5>=0 && board[i-5].second =='-')return i-5;
                if(i-4>=0 && board[i-4].second =='-')return i-4;
                if(i-1>=0 && board[i-1].second =='-')return i-1;
                if(i+1<=24 && board[i+1].second =='-')return i+1;
                if(i+4<=24 && board[i+4].second =='-')return i+4;
                if(i+5<=24 && board[i+5].second =='-')return i+5;
                if(i+6<=24 && board[i+6].second =='-')return i+6;
            }
        }
        return -1;
    }
    // Method to update the board with a symbol ('X' or 'O')
    bool update_board(int x, int y, T symbol) {
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }
        return true;
    }

    // Method to check if the game is over (either a win or a draw)
    bool game_is_over() {
        if(win)return false;
        return is_draw();
    }
};

template <typename T>
class MisereTicTacToe : public Board<T> {
private:
    vector<pair<int, T>> board; // 1D vector to represent the 3x3 board
    static const int size = 3;   // Size of the board (3x3)
    bool draw = false;
    bool win=false;
public:
    // Constructor to initialize the board with pairs of (index, '-')
    MisereTicTacToe() {
        board.clear();
        for (int i = 0; i < size * size; ++i) {
            board.emplace_back(i, '-');
        }
    }

    // Method to display the board
    void display_board() {
        if(win)return;
        const int cell_width = 6;
        int currentIndex = 0;

        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                auto [index, symbol] = board[currentIndex++];
                string index_str = to_string(index);
                cout << setw(cell_width) << left
                     << ("[" + index_str + "] " + (symbol == '-' ? "-" : string(1, symbol)));

                if (j < size - 1) {
                    cout << "|";
                }
            }

            cout << "\n";

            if (i < size - 1) {
                cout << "------+-------+------" << endl;
            }
        }
        cout << "\n";
    }

    // Method to check if there is a losing condition (three in a row)
    bool is_win() {
        if(win)return true;
        // Check horizontal rows for three consecutive symbols
        for (int row = 0; row < size; ++row) {
            int index1 = row * size;
            int index2 = row * size + 1;
            int index3 = row * size + 2;
            if (board[index1].second != '-' &&
                board[index1].second == board[index2].second &&
                board[index1].second == board[index3].second) {
                win= true; // Player loses
            }
        }

        // Check vertical columns for three consecutive symbols
        for (int col = 0; col < size; ++col) {
            int index1 = col;
            int index2 = size + col;
            int index3 = 2 * size + col;
            if (board[index1].second != '-' &&
                board[index1].second == board[index2].second &&
                board[index1].second == board[index3].second) {
                win=true; // Player loses
            }
        }

        // Check diagonal (top-left to bottom-right) for three consecutive symbols
        if (board[0].second != '-' &&
            board[0].second == board[4].second &&
            board[0].second == board[8].second) {
            win=true; // Player loses
        }

        // Check diagonal (top-right to bottom-left) for three consecutive symbols
        if (board[2].second != '-' &&
            board[2].second == board[4].second &&
            board[2].second == board[6].second) {
            win=true; // Player loses
        }

        return false; // No losing condition met
    }
    bool AI_lose(){
        for (int row = 0; row < size; ++row) {
            int index1 = row * size;
            int index2 = row * size + 1;
            int index3 = row * size + 2;
            if (board[index1].second != '-' &&
                board[index1].second == board[index2].second &&
                board[index1].second == board[index3].second) {
                return true; // Player loses
            }
        }

        // Check vertical columns for three consecutive symbols
        for (int col = 0; col < size; ++col) {
            int index1 = col;
            int index2 = size + col;
            int index3 = 2 * size + col;
            if (board[index1].second != '-' &&
                board[index1].second == board[index2].second &&
                board[index1].second == board[index3].second) {
                return true; // Player loses
            }
        }

        // Check diagonal (top-left to bottom-right) for three consecutive symbols
        if (board[0].second != '-' &&
            board[0].second == board[4].second &&
            board[0].second == board[8].second) {
            return true; // Player loses
        }

        // Check diagonal (top-right to bottom-left) for three consecutive symbols
        if (board[2].second != '-' &&
            board[2].second == board[4].second &&
            board[2].second == board[6].second) {
            return true; // Player loses
        }
        return false;
    }
    bool opponent_lose(){
        for (int row = 0; row < size; ++row) {
            int index1 = row * size;
            int index2 = row * size + 1;
            int index3 = row * size + 2;
            if (board[index1].second != '-' &&
                board[index1].second == board[index2].second &&
                board[index1].second == board[index3].second) {
                return true; // Player loses
            }
        }

        // Check vertical columns for three consecutive symbols
        for (int col = 0; col < size; ++col) {
            int index1 = col;
            int index2 = size + col;
            int index3 = 2 * size + col;
            if (board[index1].second != '-' &&
                board[index1].second == board[index2].second &&
                board[index1].second == board[index3].second) {
                return true; // Player loses
            }
        }

        // Check diagonal (top-left to bottom-right) for three consecutive symbols
        if (board[0].second != '-' &&
            board[0].second == board[4].second &&
            board[0].second == board[8].second) {
            return true; // Player loses
        }

        // Check diagonal (top-right to bottom-left) for three consecutive symbols
        if (board[2].second != '-' &&
            board[2].second == board[4].second &&
            board[2].second == board[6].second) {
            return true; // Player loses
        }
        return false;
    }
    // Method to check if the game is a draw (board is full)
    bool is_draw() {
        for (const auto &cell : board) {
            if (cell.second == '-') {
                return false; // Still empty cells, not a draw
            }
        }
        if(win)return false;
        return !is_win(); // It's a draw if no one has lost
    }

    // Method to update the board with a symbol ('X' or 'O')
    bool update_board(int x, int y, T symbol) {
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }
        return true;
    }

    // Method to check if the game is over (either a loss or a draw)
    bool game_is_over() {
        if(win)return false;
        return is_draw();
    }
    bool get_win(){
        return win;
    }
};



template<typename T>
class SUS : public Board<T> {
private:
    vector<pair<int, T>> board; // 1D vector to represent the 3x3 board
    static const int size = 3; // Size of the board (3x3)
    int player1SUSCount;
    int player2SUSCount;
    bool draw = false;
    int chosenindex;
    char chosensymbol;
    bool win=false;
public:
    // Constructor to initialize the board with pairs of (0, '-')
    SUS() {
        board.clear();
        for (int i = 0; i < size * size; ++i) {
            board.emplace_back(i, '-');
        }
        player1SUSCount = 0;
        player2SUSCount = 0;
    }

    // Method to display the board
    void display_board() {
        if(win)return;
        const int cell_width = 6;
        const int separator_width = 1;
        int currentIndex = 0;

        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                auto [index, symbol] = board[currentIndex++];
                string index_str = to_string(index);
                if (index > 9) {
                    cout << setw(cell_width) << left << ("[" + index_str + "] " + (symbol == '-' ? "-" : string(1, symbol)));
                } else {
                    cout << setw(cell_width) << left << ("[" + index_str + "]  " + (symbol == '-' ? "-" : string(1, symbol)));
                }
                if (j < size - 1) {
                    cout << "|";
                }
            }
            cout << "\n";
            if (i < size - 1) {
                cout << "------+------+------" << endl;
            }
        }
        cout << "\n";
    }
    bool get_win(){
        return win;
    }
    // Method to check if there is a winner based on "S-U-S" sequences
    bool is_win() {
        if(win)return true;
        for(auto i:board){
            if(i.second == '-'){
                return false;
            }
        }
    cout<<"Player1 scored: "<<player1SUSCount<<" Player2 scored: "<<player2SUSCount<<endl;
        // Determine the winner based on the counts
        if (player1SUSCount > player2SUSCount) return true; // Player 1 wins
        else if (player2SUSCount > player1SUSCount) {win=true;return false;} // Player 2 wins
        else{
            draw = true;
            return false;
        }
    }

    void update_count(){
        if(chosensymbol=='S'){
            if(chosenindex==0){
                if(board[1].second=='U' && board[2].second=='S')player1SUSCount++;
                if(board[3].second=='U' && board[6].second=='S')player1SUSCount++;
                if(board[4].second=='U' && board[8].second=='S')player1SUSCount++;
            }
            else if(chosenindex==1){
                if(board[4].second=='U' && board[7].second=='S')player1SUSCount++;
            }
            else if(chosenindex==2){
                if(board[1].second=='U' && board[0].second=='S')player1SUSCount++;
                if(board[4].second=='U' && board[6].second=='S')player1SUSCount++;
                if(board[5].second=='U' && board[8].second=='S')player1SUSCount++;
            }
            else if(chosenindex==3){
                if(board[4].second=='U' && board[5].second=='S')player1SUSCount++;
            }
            else if(chosenindex==5){
                if(board[4].second=='U' && board[3].second=='S')player1SUSCount++;
            }
            else if(chosenindex==6){
                if(board[3].second=='U' && board[0].second=='S')player1SUSCount++;
                if(board[4].second=='U' && board[2].second=='S')player1SUSCount++;
                if(board[7].second=='U' && board[8].second=='S')player1SUSCount++;
            }
            else if(chosenindex==7){
                if(board[4].second=='U' && board[1].second=='S')player1SUSCount++;
            }
            else if(chosenindex==8){
                if(board[5].second=='U' && board[2].second=='S')player1SUSCount++;
                if(board[4].second=='U' && board[0].second=='S')player1SUSCount++;
                if(board[7].second=='U' && board[6].second=='S')player1SUSCount++;
            }
        }
        else{
            if(chosenindex==1){
                if(board[0].second=='S' && board[2].second=='S')player2SUSCount++;
            }
            else if(chosenindex==3){
                if(board[0].second=='S' && board[6].second=='S')player2SUSCount++;
            }
            else if(chosenindex==5){
                if(board[2].second=='S' && board[8].second=='S')player2SUSCount++;
            }
            else if(chosenindex==7){
                if(board[6].second=='S' && board[8].second=='S')player2SUSCount++;
            }
            else if(chosenindex==4){
                if(board[0].second=='S' && board[8].second=='S')player2SUSCount++;
                if(board[2].second=='S' && board[6].second=='S')player2SUSCount++;
                if(board[1].second=='S' && board[7].second=='S')player2SUSCount++;
                if(board[3].second=='S' && board[5].second=='S')player2SUSCount++;
            }
        }
    }



    // Method to check if the game is a draw (board is full)
    bool is_draw() {
        if(draw)return true;
        else return false;
    }

    // Method to update the board with a symbol ('S' or 'U')
    bool update_board(int x, int y, T symbol) {
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
                chosenindex=x;
                chosensymbol=symbol;
                update_count();
            }
        }
        return true;
    }

    // Method to check if the game is over (either a win or a draw)
    bool game_is_over() {
        if(win)return false;
        return is_draw(); // Game is over if there's a winner or if it's a draw
    }
};

template<class T>
class Word_Board: public Board<T>{
    vector<pair<int, T>> board; // 1D vector to represent the 3x3 board
    static const int size = 3; // Size of the board (3x3)
    vector<string> words;
public:
    Word_Board(){
        board.clear();
        for (int i = 0; i < size * size; ++i) {
            board.emplace_back(i, '-');
        }
        fstream file("dic.txt",ios::in);
        string holder;
        while(file>>holder){
            words.push_back(holder);
        }
        file.close();
    }
    char get_value(int index){
        return toupper(board[index].second);
    }
    void display_board() {
        const int cell_width = 6;
        const int separator_width = 1;
        int currentIndex = 0;

        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                auto [index, symbol] = board[currentIndex++];
                string index_str = to_string(index);
                if (index > 9) {
                    cout << setw(cell_width) << left << ("[" + index_str + "] " + (symbol == '-' ? "-" : string(1, symbol)));
                } else {
                    cout << setw(cell_width) << left << ("[" + index_str + "]  " + (symbol == '-' ? "-" : string(1, symbol)));
                }
                if (j < size - 1) {
                    cout << "|";
                }
            }
            cout << "\n";
            if (i < size - 1) {
                cout << "------+------+------" << endl;
            }
        }
        cout << "\n";
    }

    bool is_win(){
        string holder="";
        holder += board[0].second;
        holder += board[1].second;
        holder += board[2].second;
        auto it1=find(words.begin(), words.end(), holder);
        reverse(holder.begin(), holder.end());
        auto it2=find(words.begin(), words.end(), holder);
        if(it1!=words.end() || it2!=words.end())return true;
        holder.clear();

        holder += board[3].second;
        holder += board[4].second;
        holder += board[5].second;
        it1=find(words.begin(), words.end(), holder);
        reverse(holder.begin(), holder.end());
        it2=find(words.begin(), words.end(), holder);
        if(it1!=words.end() || it2!=words.end())return true;
        holder.clear();

        holder += board[6].second;
        holder += board[7].second;
        holder += board[8].second;
        it1=find(words.begin(), words.end(), holder);
        reverse(holder.begin(), holder.end());
        it2=find(words.begin(), words.end(), holder);
        if(it1!=words.end() || it2!=words.end())return true;
        holder.clear();

        holder += board[0].second;
        holder += board[3].second;
        holder += board[6].second;
        it1=find(words.begin(), words.end(), holder);
        reverse(holder.begin(), holder.end());
        it2=find(words.begin(), words.end(), holder);
        if(it1!=words.end() || it2!=words.end())return true;
        holder.clear();

        holder += board[1].second;
        holder += board[4].second;
        holder += board[7].second;
        it1=find(words.begin(), words.end(), holder);
        reverse(holder.begin(), holder.end());
        it2=find(words.begin(), words.end(), holder);
        if(it1!=words.end() || it2!=words.end())return true;
        holder.clear();

        holder += board[2].second;
        holder += board[5].second;
        holder += board[8].second;
        it1=find(words.begin(), words.end(), holder);
        reverse(holder.begin(), holder.end());
        it2=find(words.begin(), words.end(), holder);
        if(it1!=words.end() || it2!=words.end())return true;
        holder.clear();

        holder += board[0].second;
        holder += board[4].second;
        holder += board[8].second;
        it1=find(words.begin(), words.end(), holder);
        reverse(holder.begin(), holder.end());
        it2=find(words.begin(), words.end(), holder);
        if(it1!=words.end() || it2!=words.end())return true;
        holder.clear();

        holder += board[2].second;
        holder += board[4].second;
        holder += board[6].second;
        it1=find(words.begin(), words.end(), holder);
        reverse(holder.begin(), holder.end());
        it2=find(words.begin(), words.end(), holder);
        if(it1!=words.end() || it2!=words.end())return true;
        holder.clear();
        return false;
    }

    bool is_draw() {
        for(auto i:board){
            if(i.second=='-')return false;
        }
        return true;
    }

    bool game_is_over() {
        return is_win() || is_draw();
    }

    bool update_board(int x,int y,T symbol){
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }
        return true;
    }
};




template <typename T>
class NumericalBoard : public Board<T> {
    vector<pair<int, char>> board; // 1D vector to represent the 3x3 board
    static const int size = 3;     // Size of the board (3x3)

public:
    NumericalBoard() {
        board.clear();
        for (int i = 0; i <=8; ++i) {
            board.emplace_back(i, '-');
        }
        this->rows = size;
        this->columns = size;
        this->n_moves = 0;
    }

    // Convert 2D index to 1D index
    int to_index(int x, int y) {
        return x * this->columns + y;
    }

    bool update_board(int x, int y, T symbol) override {
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }
        return true;
    }

    void display_board() override {
        for (int i = 0; i < this->rows; ++i) {
            for (int j = 0; j < this->columns; ++j) {
                int index = to_index(i, j);

                // Print the character at the position or "-" if empty
                cout << "[" << board[index].first << "] "
                     << (board[index].second == '-' ? "-" : string(1, board[index].second))
                     << " ";

                // Add column separator
                if (j < this->columns - 1) {
                    cout << "|";
                }
            }
            cout << endl;

            // Add row separator (except after the last row)
            if (i < this->rows - 1) {
                for (int k = 0; k < this->columns; ++k) {
                    cout << "------"; // Adjust separator length as needed
                    if (k < this->columns - 1) {
                        cout << "+";
                    }
                }
                cout << endl;
            }
        }
    }

    bool is_win() override {
        auto char_to_int = [](char c) -> int {
            return c == '-' ? -100 : c - '0'; // Convert char to int or 0 if the cell is empty
        };

        if((char_to_int(board[0].second) + char_to_int(board[1].second) + char_to_int(board[2].second))==15)return true;
        if((char_to_int(board[3].second) + char_to_int(board[4].second) + char_to_int(board[5].second))==15)return true;
        if((char_to_int(board[6].second) + char_to_int(board[7].second) + char_to_int(board[8].second))==15)return true;
        if((char_to_int(board[0].second) + char_to_int(board[3].second) + char_to_int(board[6].second))==15)return true;
        if((char_to_int(board[1].second) + char_to_int(board[4].second) + char_to_int(board[7].second))==15)return true;
        if((char_to_int(board[2].second) + char_to_int(board[5].second) + char_to_int(board[8].second))==15)return true;
        if((char_to_int(board[0].second) + char_to_int(board[4].second) + char_to_int(board[8].second)==15))return true;
        if((char_to_int(board[2].second) + char_to_int(board[4].second) + char_to_int(board[6].second)==15))return true;
        return false;

    }

    bool is_draw() override {
        for(auto i:board){
            if(i.second=='-')return false;
        }
        return true;
    }

    bool game_is_over() override {
        return is_win() || is_draw();
    }
};


template <typename T>
class UltimateTicTacToe : public Board<T> {
private:
    vector<pair<int, T>> board; // 1D vector to represent the 3x3 board
    static const int size = 9;   // Size of the board (3x3)
    vector<pair<int,char>> main_board;
    vector<int> grid_offsets = {0, 3, 6, 27, 30, 33, 54, 57, 60};
    void board_win() {
        // Offsets for the 3x3 grids within the 9x9 board

        for (int grid_index = 0; grid_index < grid_offsets.size(); ++grid_index) {
            int offset = grid_offsets[grid_index]; // Top-left index of current 3x3 grid
            char winner = '-'; // Tracks the winner for this grid

            // Check rows, columns, and diagonals for a win in the 3x3 grid
            vector<int> rows = {0, 1, 2};
            for (int i : rows) {
                // Row check
                if (board[offset + i * 9].second != '-' &&
                    board[offset + i * 9].second == board[offset + i * 9 + 1].second &&
                    board[offset + i * 9].second == board[offset + i * 9 + 2].second) {
                    winner = board[offset + i * 9].second;
                    break;
                }
                // Column check
                if (board[offset + i].second != '-' &&
                    board[offset + i].second == board[offset + i + 9].second &&
                    board[offset + i].second == board[offset + i + 18].second) {
                    winner = board[offset + i].second;
                    break;
                }
            }
            // Diagonal checks
            if (winner == '-') { // Only check diagonals if no winner found yet
                if (board[offset].second != '-' &&
                    board[offset].second == board[offset + 10].second &&
                    board[offset].second == board[offset + 20].second) {
                    winner = board[offset].second;
                }
                if (board[offset + 2].second != '-' &&
                    board[offset + 2].second == board[offset + 10].second &&
                    board[offset + 2].second == board[offset + 18].second) {
                    winner = board[offset + 2].second;
                }
            }

            // Update main_board and remove the grid index if a winner is found
            if (winner != '-') {
                if(main_board[grid_index].second=='-') {
                    main_board[grid_index].second = winner;
                    continue; // Skip checking for draw if a winner is found
                }
            }

            // Check if the grid is a draw (all cells filled)
            bool is_draw = true;
            for (int i = 0; i < 9; ++i) {
                if (board[offset + (i / 3) * 9 + (i % 3)].second == '-') {
                    is_draw = false;
                    break;
                }
            }

            // Update main_board if grid is a draw
            if (is_draw) {
                if(main_board[grid_index].second=='-')main_board[grid_index].second = 'D';
            }
        }
    }

public:
    // Constructor to initialize the board with pairs of (index, '-')
    UltimateTicTacToe() {
        board.clear();
        for (int i = 0; i < size * size; ++i) {
            board.emplace_back(i, '-');
        }
        for(int i=0; i<9; i++){
            main_board.emplace_back(i,'-');
        }
    }

    // Method to display the board
    void display_board() {
        const int cell_width = 6;
        int currentIndex = 0;

        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                auto [index, symbol] = board[currentIndex++];
                string index_str = to_string(index);
                if(index<=9)
                cout << setw(cell_width) << left
                     << ("[" + index_str + "] " + (symbol == '-' ? " -" : " "+string(1, symbol)));
                else cout << setw(cell_width) << left
                          << ("[" + index_str + "] " + (symbol == '-' ? "-" : string(1, symbol)));


                if (j < size - 1) {
                    cout << "|";
                }
            }

            cout << "\n";

            if (i < size - 1) {
                cout << "------+------+------+------+------+------+------+------+------" << endl;
            }
        }
        cout << "\n";
        board_win();
        for (int i = 0; i < main_board.size(); ++i) {
            cout << main_board[i].second << " "; // Print the value
            if ((i + 1) % 3 == 0) {             // After every 3 elements, print a new line
                cout << endl;
            }
        }

    }


    // Method to check if there is a losing condition (three in a row)
    bool is_win() {
        board_win();
        if(main_board[0].second!='-' && main_board[0].second!='D' && main_board[0].second==main_board[1].second && main_board[0].second==main_board[2].second)return true;
        if(main_board[0].second!='-' && main_board[0].second!='D' && main_board[0].second==main_board[3].second && main_board[0].second==main_board[6].second)return true;
        if(main_board[0].second!='-' && main_board[0].second!='D' && main_board[4].second==main_board[0].second && main_board[0].second==main_board[8].second)return true;
        if(main_board[3].second!='-' && main_board[3].second!='D' && main_board[3].second==main_board[4].second && main_board[3].second==main_board[5].second)return true;
        if(main_board[6].second!='-' && main_board[6].second!='D' && main_board[6].second==main_board[7].second && main_board[6].second==main_board[8].second)return true;
        if(main_board[1].second!='-' && main_board[1].second!='D' && main_board[1].second==main_board[4].second && main_board[1].second==main_board[7].second)return true;
        if(main_board[2].second!='-' && main_board[2].second!='D' && main_board[2].second==main_board[5].second && main_board[2].second==main_board[8].second)return true;
        if(main_board[2].second!='-' && main_board[2].second!='D' && main_board[2].second==main_board[4].second && main_board[2].second==main_board[6].second)return true;
        return false;
    }

    // Method to check if the game is a draw (board is full)
    bool is_draw() {
        for (const auto &cell : main_board) {
            if (cell.second == '-') {
                return false; // Still empty cells, not a draw
            }
        }
        return true;
    }

    // Method to update the board with a symbol ('X' or 'O')
    bool update_board(int x, int y, T symbol) {
        for (auto& cell : board) {
            if (cell.first == x) {
                cell.second = symbol;
            }
        }
        return true;
    }

    // Method to check if the game is over (either a loss or a draw)
    bool game_is_over() {
        return is_win() || is_draw();
    }

};
#endif